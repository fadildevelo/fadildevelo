
[![Build](https://img.shields.io/badge/Spam-X-brightgreen.svg?maxAge=259200)]()
[![Stage](https://img.shields.io/badge/Version-1.0-brightgreen.svg)]()
[![Build](https://img.shields.io/badge/Support-Termux-orange.svg)]()
[![Build](https://img.shields.io/badge/Language-Python2-blue.svg?maxAge=259200)]()
[![Build](https://img.shields.io/badge/Contributor-Rahmat_Dev&Ilham_Dev-red.svg?style=flat)]()

![Banner](https://raw.githubusercontent.com/Anak-IT/Spam-X/main/.readme/Banner.jpg)

**Spam-X** Is A sms spammer tool, using python2, the spam-x is a great tool for prank your friends

## Requirements
- [python2](https://www.python.org/downloads/release/python-2717) written in python2
- [git](https://git-scm.com/downloads) of course
- [requests](https://pypi.org/project/requests) to make http requests
- [mechanize](https://pypi.org/project/mechanize) 

## Installation
How to install *Spam-X* 
```bash
 $ apt update && apt upgrade
 $ apt install python2
 $ apt install git
 $ apt install curl
 $ git clone https://github.com/Anak-IT/Spam-X
 $ cd Spam-X
 $ pip2 install -r requirements.txt
 $ python2 index.py
```
## Tools Overview
| Front View |
| ------------  |
|![Index](https://raw.githubusercontent.com/Anak-IT/Spam-X/main/.readme/Overview.jpg)|

### About issues
- Read the [README.md](https://github.com/Anak-IT/Spam-X/blob/master/README.md) before making an issue.

<h3 align="center">
    Copyright©2K21 Rahmat_Dev & Ilham_Dev
</h3>

