import os, socket, requests, datetime
from flask import Flask, render_template_string, request, send_from_directory, redirect, url_for
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = './uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# data sementara (kalau mau permanen bisa pakai DB / JSON)
files_data = []   # [{name,date,views,link}]
total_views = 0

HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>📂 Dashboard File Kamu</title>
<style>
:root {
  --bg: #000;
  --panel: #111;
  --accent: #ffdd33;
  --text-main: #fff;
  --text-sub: #ccc;
  --hover: #222;
}
* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: "Fira Code", monospace;
  background: var(--bg);
  color: var(--text-main);
  line-height: 1.4;
}
header {
  background: var(--panel);
  padding: 16px 20px;
  font-size: 22px;
  font-weight: bold;
  color: var(--accent);
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 8px;
  border-bottom: 2px solid #333;
}
#clock {
  font-size: 14px;
  color: #0f0;
  background: rgba(255,255,255,0.1);
  padding: 6px 10px;
  border-radius: 5px;
  font-weight: bold;
}
.stats {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin: 20px;
}
.stat-box {
  background: var(--panel);
  padding: 20px;
  border-radius: 12px;
  flex: 1 1 200px;
  text-align: center;
  box-shadow: 0 0 8px rgba(255,255,255,0.05);
  min-width: 200px;
}
.stat-box h3 { margin: 0; font-size: 16px; color: var(--text-sub); }
.stat-box p { margin: 8px 0 0; font-size: 28px; font-weight: bold; }
.upload-btn {
  background: var(--accent);
  color: #000;
  padding: 12px 20px;
  font-weight: bold;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  width: 100%;
  font-size: 16px;
}
.upload-btn:hover { background: #ffe766; }
table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
th, td {
  padding: 12px 10px;
  border-bottom: 1px solid #333;
  text-align: left;
}
th {
  background: var(--panel);
  color: var(--accent);
  font-size: 14px;
  text-transform: uppercase;
}
tr:hover { background: var(--hover); }
a { color: #66ff99; text-decoration: none; font-weight: bold; }
a.delete { color: #ff6666; }
form.extra {
  background: var(--panel);
  padding: 20px;
  border-radius: 12px;
  margin: 20px;
  max-width: 500px;
}
input[type=text] {
  width: 100%;
  margin-bottom: 12px;
  background: #000;
  border: 1px solid #444;
  color: #fff;
  padding: 10px;
  border-radius: 6px;
  font-size: 14px;
}
input[type=submit] {
  padding: 12px;
  width: 100%;
  border: none;
  background: #33cc99;
  color: #000;
  font-weight: bold;
  border-radius: 6px;
  font-size: 16px;
  cursor: pointer;
}
input[type=submit]:hover { background: #28a77e; }
p.note {
  background: var(--hover);
  padding: 12px;
  border-radius: 6px;
  margin: 10px 20px;
}
h2 {
  margin: 30px 20px 10px 20px;
  font-size: 20px;
  color: var(--accent);
}
@media (max-width: 600px) {
  header { font-size: 18px; flex-direction: column; align-items: flex-start; }
  .stats { flex-direction: column; }
}
</style>
</head>
<body>
<header>
  📂 Dashboard File Kamu
  <div id="clock">--:--:-- WIB</div>
</header>

<div class="stats">
  <div class="stat-box">
    <h3>Link Dibuat</h3>
    <p>{{ total_files }}</p>
  </div>
  <div class="stat-box">
    <h3>Total Akses</h3>
    <p>{{ total_views }}</p>
  </div>
  <div class="stat-box">
    <form action="/upload" method="POST" enctype="multipart/form-data">
      <input type="file" name="file" accept=".html,.htm" required>
      <button class="upload-btn" type="submit">✅ Upload Baru</button>
    </form>
  </div>
</div>

<div style="margin:20px;">
  <h2>📑 Daftar File Kamu</h2>
  <div style="overflow-x:auto;">
    <table>
      <tr>
        <th>Nama File</th>
        <th>Tanggal</th>
        <th>View</th>
        <th>Link</th>
        <th>Aksi</th>
      </tr>
      {% for f in files %}
      <tr>
        <td>{{ f.name }}</td>
        <td>{{ f.date }}</td>
        <td>{{ f.views }}</td>
        <td><a href="{{ f.link }}" target="_blank">Buka</a></td>
        <td><a class="delete" href="/delete/{{ f.name }}">Hapus</a></td>
      </tr>
      {% endfor %}
    </table>
  </div>
</div>

<!-- FITUR EXISTING -->
<style>
.tools-container{
  display:flex;
  flex-wrap:wrap;
  gap:20px;
  margin:20px;
}
.tools-left, .tools-right{
  flex:1 1 300px;
  min-width:300px;
}
.tools-left > h2,
.tools-right > h2 { margin-top:0; }
</style>

<div class="tools-container">
  <!-- BAGIAN KIRI -->
  <div class="tools-left">
    <h2>🔎 Track IP</h2>
    <form class="extra" action="/track_ip" method="POST">
      <input type="text" name="target_ip" placeholder="Masukkan IP / Domain">
      <input type="submit" value="Track IP">
    </form>
    {% if track_msg %}
    <p class="note">{{ track_msg|safe }}</p>
    {% endif %}

    <h2>✅ Cek HTTPS</h2>
    <form class="extra" action="/cek_https" method="POST">
      <input type="text" name="url" placeholder="https://example.com">
      <input type="submit" value="Cek HTTPS">
    </form>
    {% if https_msg %}
    <p class="note">{{ https_msg }}</p>
    {% endif %}

    <h2>🤖 Spam Bot Telegram</h2>
    <form class="extra" action="/spam_tele" method="POST">
      <input type="text" name="bot_token" placeholder="Masukkan Bot Token (API Key)">
      <input type="text" name="chat_id" placeholder="Masukkan Chat ID">
      <input type="text" name="pesan" placeholder="Tulis Pesan">
      <input type="submit" value="Kirim Pesan">
    </form>
    {% if spam_msg %}
    <p class="note">{{ spam_msg }}</p>
    {% endif %}
  </div>

  <!-- BAGIAN KANAN -->
  <div class="tools-right">
    <h2>🆔 Cek NIK</h2>
    <form class="extra" action="/cek_nik" method="POST">
      <input type="text" name="nik" placeholder="Masukkan NIK">
      <input type="submit" value="Cek NIK">
    </form>
    {% if nik_msg %}
    <p class="note">{{ nik_msg }}</p>
    {% endif %}

    <h2>📡 Cek Ping VPS</h2>
    <form class="extra" action="/cek_ping" method="POST">
      <input type="text" name="host" placeholder="Masukkan IP / Host VPS">
      <input type="submit" value="Ping Sekarang">
    </form>
    {% if ping_msg %}
    <p class="note">{{ ping_msg }}</p>
    {% endif %}
  </div>
</div>

<script>
function updateClock(){
  const d = new Date();
  const utc = d.getTime() + (d.getTimezoneOffset()*60000);
  const nd = new Date(utc + (3600000*7)); // WIB
  const h = String(nd.getHours()).padStart(2,'0');
  const m = String(nd.getMinutes()).padStart(2,'0');
  const s = String(nd.getSeconds()).padStart(2,'0');
  document.getElementById('clock').innerText = h+":"+m+":"+s+" WIB";
}
setInterval(updateClock,1000);
updateClock();
</script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(
        HTML,
        total_files=len(files_data),
        total_views=sum(f['views'] for f in files_data),
        files=files_data,
        track_msg=None,
        https_msg=None,
        spam_msg=None
    )

@app.route('/upload', methods=['POST'])
def upload():
    f = request.files['file']
    if f:
        fn = secure_filename(f.filename)
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], fn)
        f.save(save_path)
        files_data.append({
            'name': fn,
            'date': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'views': 0,
            'link': f'/uploads/{fn}'
        })
    return redirect('/')

@app.route('/delete/<filename>')
def delete(filename):
    global files_data
    files_data = [f for f in files_data if f['name'] != filename]
    try:
        os.remove(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    except:
        pass
    return redirect('/')

@app.route('/uploads/<path:filename>')
def serve_file(filename):
    # tambah view
    for f in files_data:
        if f['name'] == filename:
            f['views'] += 1
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/track_ip', methods=['POST'])
def track_ip():
    target_ip = request.form.get('target_ip','').strip()
    track_msg = ""
    if target_ip:
        try:
            r = requests.get(f"https://ipwho.is/{target_ip}", timeout=6)
            if r.status_code == 200:
                data = r.json()
                track_msg = (
                    f"🌐 IP: {data.get('ip','-')}<br>"
                    f"📍 Kota: {data.get('city','-')}<br>"
                    f"🏳 Negara: {data.get('country_name','-')}<br>"
                    f"🕹 ISP: {data.get('org','-')}<br>"
                    f"🧭 Koordinat: {data.get('latitude','-')}, {data.get('longitude','-')}"
                )
            else:
                track_msg = f"❌ Gagal cek IP, kode {r.status_code}"
        except Exception as e:
            track_msg = f"❌ Error: {e}"
    else:
        track_msg = "⚠️ Masukkan IP atau domain!"

    return render_template_string(
        HTML,
        total_files=len(files_data),
        total_views=sum(f['views'] for f in files_data),
        files=files_data,
        track_msg=track_msg,
        https_msg=None,
        spam_msg=None
    )

@app.route('/cek_nik', methods=['POST'])
def cek_nik():
    nik = request.form.get('nik','').strip()
    if not nik:
        nik_msg = "⚠️ Masukkan NIK!"
    else:
        # Contoh dummy validasi
        if len(nik) == 16 and nik.isdigit():
            nik_msg = f"✅ NIK {nik} valid (dummy)"
        else:
            nik_msg = f"❌ NIK {nik} tidak valid"
    return render_template_string(HTML, nik_msg=nik_msg, **default_context())

@app.route('/cek_ping', methods=['POST'])
def cek_ping():
    host = request.form.get('host','').strip()
    if not host:
        ping_msg = "⚠️ Masukkan Host!"
    else:
        try:
            import subprocess
            result = subprocess.run(["ping","-c","1","-W","1",host],
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if result.returncode == 0:
                ping_msg = f"✅ VPS {host} aktif!\n\n{result.stdout}"
            else:
                ping_msg = f"❌ Gagal ping {host}\n\n{result.stderr}"
        except Exception as e:
            ping_msg = f"❌ Error: {e}"
    return render_template_string(HTML, ping_msg=ping_msg, **default_context())
    
@app.route('/cek_https', methods=['POST'])
def cek_https():
    url = request.form.get('url','').strip()
    https_msg = ""
    if url:
        try:
            r = requests.get(url, timeout=5)
            if url.startswith('https://'):
                https_msg = f"✅ {url} menggunakan HTTPS (status {r.status_code})"
            else:
                https_msg = f"⚠️ {url} tidak HTTPS"
        except Exception as e:
            https_msg = f"❌ Gagal cek: {e}"
    else:
        https_msg = "⚠️ Masukkan URL!"

    return render_template_string(
        HTML,
        total_files=len(files_data),
        total_views=sum(f['views'] for f in files_data),
        files=files_data,
        track_msg=None,
        https_msg=https_msg,
        spam_msg=None
    )

@app.route('/spam_tele', methods=['POST'])
def spam_tele():
    token = request.form.get('bot_token','').strip()
    chat_id = request.form.get('chat_id','').strip()
    pesan = request.form.get('pesan','').strip()
    msg = ""
    if token and chat_id and pesan:
        try:
            r = requests.get(
                f"https://api.telegram.org/bot{token}/sendMessage",
                params={'chat_id': chat_id, 'text': pesan}
            )
            if r.status_code == 200:
                msg = f"✅ Pesan berhasil dikirim ke chat_id {chat_id}!"
            else:
                msg = f"❌ Gagal kirim, kode: {r.status_code} - {r.text}"
        except Exception as e:
            msg = f"❌ Error: {e}"
    else:
        msg = "⚠️ Lengkapi semua field!"

    return render_template_string(
        HTML,
        total_files=len(files_data),
        total_views=sum(f['views'] for f in files_data),
        files=files_data,
        track_msg=None,
        https_msg=None,
        spam_msg=msg
    )

def find_free_port(start=5000,end=5100):
    for p in range(start,end):
        with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
            try:
                s.bind(("0.0.0.0",p))
                return p
            except OSError:
                continue
    raise RuntimeError("No free port")

if __name__ == '__main__':
    port = find_free_port()
    print(f"[✓] Server running on http://127.0.0.1:{port}")
    app.run(host='0.0.0.0', port=port, debug=True)