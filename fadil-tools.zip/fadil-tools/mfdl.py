import os
import requests
from bs4 import BeautifulSoup

def download_mediafire(url: str, output_dir: str = "./downloads"):
    # Buat folder output jika belum ada
    os.makedirs(output_dir, exist_ok=True)

    print(f"[INFO] Mengakses halaman: {url}")
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        raise Exception(f"Gagal akses MediaFire (status {response.status_code})")

    # Parse HTML
    soup = BeautifulSoup(response.text, "html.parser")
    download_button = soup.select_one("#downloadButton")
    if not download_button:
        raise Exception("❌ Gagal menemukan tombol download. File mungkin dilindungi captcha atau link salah.")

    # Ambil link langsung
    direct_link = download_button.get("href")
    filename = os.path.basename(direct_link.split("?")[0])
    filepath = os.path.join(output_dir, filename)

    print(f"[INFO] Nama File : {filename}")
    print(f"[INFO] Link File : {direct_link}")
    print("[INFO] Mulai mendownload...")

    with requests.get(direct_link, stream=True) as r:
        r.raise_for_status()
        total_size = int(r.headers.get('content-length', 0))
        downloaded = 0
        chunk_size = 8192

        with open(filepath, "wb") as f:
            for chunk in r.iter_content(chunk_size=chunk_size):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        percent = int(downloaded * 100 / total_size)
                        print(f"\r[PROGRESS] {percent}% ({downloaded}/{total_size} bytes)", end="")
    print(f"\n✅ Selesai! File disimpan di: {filepath}")

if __name__ == "__main__":
    # Input URL dan folder dari user
    url = input("Masukkan URL MediaFire: ").strip()
    output = input("Simpan ke folder (tekan Enter untuk ./downloads): ").strip()
    if output == "":
        output = "./downloads"

    try:
        download_mediafire(url, output)
    except Exception as e:
        print(f"[ERROR] {e}")