import os, socket, requests
from flask import Flask, render_template_string, request, send_from_directory
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = './uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>🛠 Multi Tools</title>
<style>
  body {
    margin:0;
    font-family: "Fira Code", monospace;
    background: #0f111a;
    color: #66ffcc;
    min-height: 100vh;
    padding:20px;
    position:relative;
    overflow-x:hidden;
    line-height:1.5;
  }
  body::before {
    content:"";
    position:fixed;
    top:0; left:0; right:0; bottom:0;
    background:
      linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px),
      linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px);
    background-size:20px 20px;
    z-index:0;
    pointer-events:none;
    animation: moveGrid 10s linear infinite;
  }
  @keyframes moveGrid {
    0% {background-position:0 0,0 0;}
    100% {background-position:20px 20px,20px 20px;}
  }
  h1,h2 {
    z-index:1;
    text-shadow:0 0 3px #33cc99;
    font-weight:500;
  }
  form {
    z-index:1;
    background:rgba(0,255,153,0.08);
    border:1px solid #33cc99;
    padding:15px;
    border-radius:8px;
    margin:15px 0 30px 0;
    width:100%;
    max-width:400px;
    box-shadow:0 0 6px rgba(0,255,153,0.2);
  }
  input[type=file],input[type=text] {
    width:100%;
    margin-bottom:10px;
    background:#1a1c2c;
    border:1px solid #33cc99;
    color:#ccffdd;
    padding:8px;
    border-radius:4px;
    outline:none;
  }
  input[type=submit], button {
    padding:10px;
    width:100%;
    border:none;
    background:#33cc99;
    color:#0f111a;
    font-weight:600;
    border-radius:4px;
    cursor:pointer;
    transition:0.3s;
  }
  input[type=submit]:hover, button:hover {
    background:#28a77e;
  }
  p {
    z-index:1;
    margin-top:10px;
    background:rgba(255,255,255,0.05);
    padding:10px;
    border-radius:5px;
    word-break:break-word;
  }
  #clock {
    position:fixed;
    top:10px;
    right:20px;
    font-size:14px;
    color:#99ffcc;
    background:rgba(0,0,0,0.5);
    padding:6px 10px;
    border-radius:5px;
    z-index:2;
    box-shadow:0 0 5px rgba(0,255,153,0.2);
    font-weight:500;
  }

  /* Loading Overlay */
  #loadingOverlay {
    position:fixed;
    top:0; left:0; right:0; bottom:0;
    background:#0f111a;
    display:flex;
    justify-content:center;
    align-items:center;
    z-index:9999;
  }
  .spinner {
    border:6px solid rgba(255,255,255,0.1);
    border-top:6px solid #33cc99;
    border-radius:50%;
    width:60px;
    height:60px;
    animation: spin 1s linear infinite;
  }
  @keyframes spin {
    0% {transform:rotate(0deg);}
    100% {transform:rotate(360deg);}
  }
</style>
</head>
<body>
  <div id="loadingOverlay"><div class="spinner"></div></div>

  <div id="clock">WIB: --:--:--</div>
  <h1>🛠 Multi Tools Portal</h1>

  <h2>📂 Upload File HTML</h2>
  <form method="POST" enctype="multipart/form-data">
    <input type="file" name="file" accept=".html,.htm">
    <input type="submit" value="Upload">
  </form>
  {% if upload_msg %}
  <p>{{upload_msg|safe}}</p>
  {% endif %}

  <h2>🔎 Crack IP (Custom)</h2>
  <form action="/crack_ip" method="POST">
    <input type="text" name="target_ip" placeholder="Masukkan IP / Domain Target">
    <input type="submit" value="Crack IP">
  </form>
  {% if crack_msg %}
  <p>{{crack_msg|safe}}</p>
  {% endif %}

  <h2>🖥 VPS Public IP</h2>
  <form method="POST">
    <input type="hidden" name="action" value="cek_vps">
    <input type="submit" value="Cek VPS IP">
  </form>
  {% if vps_msg %}
  <p>{{vps_msg}}</p>
  {% endif %}

  <h2>✅ Cek HTTPS</h2>
  <form method="POST">
    <input type="text" name="url" placeholder="https://example.com">
    <input type="hidden" name="action" value="cek_https">
    <input type="submit" value="Cek HTTPS">
  </form>
  {% if https_msg %}
  <p>{{https_msg}}</p>
  {% endif %}

  <h2>📞 Cek Nomor (Dummy)</h2>
  <form method="POST">
    <input type="text" name="nomor" placeholder="Masukkan Nomor">
    <input type="hidden" name="action" value="cek_nomor">
    <input type="submit" value="Cek Nomor">
  </form>
  {% if nomor_msg %}
  <p>{{nomor_msg}}</p>
  {% endif %}

  <h2>🤖 Spam Bot Telegram (Custom Token)</h2>
  <form action="/spam_tele" method="POST">
    <input type="text" name="bot_token" placeholder="Masukkan Bot Token (API Key)">
    <input type="text" name="chat_id" placeholder="Masukkan Chat ID">
    <input type="text" name="pesan" placeholder="Tulis Pesan">
    <input type="submit" value="Kirim Pesan">
  </form>
  {% if spam_msg %}
  <p>{{spam_msg}}</p>
  {% endif %}

<script>
function updateClock(){
  let d = new Date();
  let utc = d.getTime() + (d.getTimezoneOffset() * 60000);
  let nd = new Date(utc + (3600000*7));
  let h = String(nd.getHours()).padStart(2,'0');
  let m = String(nd.getMinutes()).padStart(2,'0');
  let s = String(nd.getSeconds()).padStart(2,'0');
  document.getElementById('clock').innerText = "WIB: "+h+":"+m+":"+s;
}
setInterval(updateClock,1000);
updateClock();

window.addEventListener('load',()=>{
  setTimeout(()=>{
    document.getElementById('loadingOverlay').style.display='none';
  },1000);
});
</script>
</body>
</html>
"""

@app.route('/crack_ip', methods=['POST'])
def crack_ip():
    target_ip = request.form.get('target_ip', '').strip()
    crack_msg = ""
    if target_ip:
        try:
            r = requests.get(f"https://ipwho.is/{target_ip}", timeout=6)
            if r.status_code == 200:
                data = r.json()
                crack_msg = (
                    f"🌐 IP: {data.get('ip','-')}<br>"
                    f"📍 Kota: {data.get('city','-')}<br>"
                    f"🏳 Negara: {data.get('country_name','-')} ({data.get('country_code','-')})<br>"
                    f"🕹 ISP: {data.get('org','-')}<br>"
                    f"🧭 Koordinat: {data.get('latitude','-')}, {data.get('longitude','-')}"
                )
            else:
                crack_msg = f"❌ Gagal cek IP, kode {r.status_code}"
        except Exception as e:
            crack_msg = f"❌ Error: {e}"
    else:
        crack_msg = "⚠️ Masukkan IP atau domain!"

    return render_template_string(
        HTML,
        upload_msg="",
        ip=request.remote_addr,
        vps_msg="",
        https_msg="",
        nomor_msg="",
        spam_msg="",
        crack_msg=crack_msg
    )

@app.route('/', methods=['GET','POST'])
def index():
    upload_msg = ""
    vps_msg = ""
    https_msg = ""
    nomor_msg = ""
    ip = request.remote_addr

    if request.method == 'POST':
        action = request.form.get('action','')
        if 'file' in request.files and action == '':
            f = request.files['file']
            if f and f.filename != '':
                fn = secure_filename(f.filename)
                path = os.path.join(app.config['UPLOAD_FOLDER'], fn)
                f.save(path)
                upload_msg = f"✅ File berhasil diupload!<br>Akses di: <a href='/uploads/{fn}' target='_blank'>/uploads/{fn}</a>"

        if action == 'cek_vps':
            try:
                r = requests.get('https://api.ipify.org?format=json', timeout=5)
                ipdata = r.json().get('ip','(tidak ditemukan)')
                vps_msg = f"🌐 IP VPS: {ipdata}"
            except Exception as e:
                vps_msg = f"❌ Gagal cek VPS IP: {e}"

        if action == 'cek_https':
            url = request.form.get('url','').strip()
            if url:
                try:
                    r = requests.get(url, timeout=5)
                    if url.startswith('https://'):
                        https_msg = f"✅ {url} menggunakan HTTPS (status {r.status_code})"
                    else:
                        https_msg = f"⚠️ {url} tidak HTTPS"
                except Exception as e:
                    https_msg = f"❌ Gagal cek: {e}"
            else:
                https_msg = "⚠️ Masukkan URL!"

        if action == 'cek_nomor':
            nomor = request.form.get('nomor','').strip()
            if nomor:
                nomor_msg = f"Hasil cek nomor {nomor}: ✅ Nomor valid (dummy)"
            else:
                nomor_msg = "⚠️ Masukkan nomor!"

    return render_template_string(
        HTML,
        upload_msg=upload_msg,
        ip=ip,
        vps_msg=vps_msg,
        https_msg=https_msg,
        nomor_msg=nomor_msg,
        spam_msg="",
        crack_msg=""
    )

@app.route('/spam_tele', methods=['POST'])
def spam_tele():
    token = request.form.get('bot_token','').strip()
    chat_id = request.form.get('chat_id','').strip()
    pesan = request.form.get('pesan','').strip()
    msg = ""
    if token and chat_id and pesan:
        try:
            r = requests.get(
                f"https://api.telegram.org/bot{token}/sendMessage",
                params={'chat_id': chat_id, 'text': pesan}
            )
            if r.status_code == 200:
                msg = f"✅ Pesan berhasil dikirim ke chat_id {chat_id}!"
            else:
                msg = f"❌ Gagal kirim, kode: {r.status_code} - {r.text}"
        except Exception as e:
            msg = f"❌ Error: {e}"
    else:
        msg = "⚠️ Lengkapi semua field!"

    return render_template_string(
        HTML,
        upload_msg="",
        ip=request.remote_addr,
        vps_msg="",
        https_msg="",
        nomor_msg="",
        spam_msg=msg,
        crack_msg=""
    )

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

def find_free_port(start=5000,end=5100):
    for p in range(start,end):
        with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
            try:
                s.bind(("0.0.0.0",p))
                return p
            except OSError:
                continue
    raise RuntimeError("No free port")

if __name__=='__main__':
    port = find_free_port()
    print(f"[✓] Server running on http://127.0.0.1:{port}")
    app.run(host='0.0.0.0',port=port,debug=True)