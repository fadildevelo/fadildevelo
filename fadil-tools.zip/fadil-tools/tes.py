#!/usr/bin/env python3
import hashlib
import os
import requests

# Warna
W = "\033[0m"
R = "\033[31m"
G = "\033[32m"
Y = "\033[33m"
C = "\033[36m"

def clear():
    os.system("clear" if os.name != "nt" else "cls")

def encode_hash(teks: str):
    md5 = hashlib.md5(teks.encode()).hexdigest()
    sha1 = hashlib.sha1(teks.encode()).hexdigest()
    sha256 = hashlib.sha256(teks.encode()).hexdigest()
    return md5, sha1, sha256

def decode_hash(hash_value: str):
    """
    Contoh decode pakai API hashlookup (publik).
    Bisa kamu ganti API-nya sesuai kebutuhanmu.
    """
    try:
        url = f"https://api.hashlookup.app/api.php?md5={hash_value}"
        r = requests.get(url, timeout=10)
        if r.status_code == 200 and r.text.strip():
            return r.text.strip()
        else:
            return None
    except Exception as e:
        return None

def menu():
    while True:
        clear()
        print(f"{C}=== HASH TOOLS XPLOIT ==={W}")
        print(f"{Y}[1]{W} Encode teks ke MD5/SHA1/SHA256")
        print(f"{Y}[2]{W} Decode hash (cek ke database online)")
        print(f"{Y}[3]{W} Keluar")
        pilihan = input(f"{C}Pilih > {W}")
        if pilihan == "1":
            teks = input(f"{Y}Masukkan teks: {W}")
            md5, sha1, sha256 = encode_hash(teks)
            print(f"{G}MD5   : {md5}{W}")
            print(f"{G}SHA1  : {sha1}{W}")
            print(f"{G}SHA256: {sha256}{W}")
            input(f"{C}Tekan ENTER untuk kembali...{W}")
        elif pilihan == "2":
            h = input(f"{Y}Masukkan hash MD5: {W}")
            hasil = decode_hash(h)
            if hasil:
                print(f"{G}✓ Hash ditemukan: {hasil}{W}")
            else:
                print(f"{R}× Hash tidak ditemukan di database publik.{W}")
            input(f"{C}Tekan ENTER untuk kembali...{W}")
        elif pilihan == "3":
            print(f"{G}✓ Keluar...{W}")
            break
        else:
            print(f"{R}× Pilihan salah!{W}")
            input("Tekan ENTER untuk ulang...")

if __name__ == "__main__":
    menu()