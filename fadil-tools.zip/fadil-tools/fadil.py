#!/usr/bin/env python3
import os, shutil, time

# Warna terminal
W = "\033[0m"
R = "\033[31m"
G = "\033[32m"
Y = "\033[33m"
C = "\033[36m"

def clear():
    os.system("clear" if os.name != "nt" else "cls")

def cek_paket(paket):
    """Cek apakah paket tersedia, kalau belum coba install"""
    print(f"{C}• Mengecek {paket}...{W}")
    res = shutil.which(paket)
    if res:
        print(f"{G}✓ {paket} sudah terinstall{W}")
    else:
        print(f"{R}× {paket} belum ada, sedang install...{W}")
        try:
            # Sesuaikan dengan sistem kamu (Termux/Debian)
            os.system(f"apt install {paket} -y || pkg install {paket} -y")
            print(f"{G}✓ {paket} terinstall{W}")
        except Exception as e:
            print(f"{R}Gagal install {paket}: {e}{W}")
    time.sleep(0.5)

def banner():
    """Tampilkan banner utama"""
    clear()
    # pakai figlet kalau ada, kalau tidak pakai echo
    os.system("figlet SCRIPT XPLOIT V1 || echo '=== SCRIPT XPLOIT V1 ==='")
    print()

def menu():
    while True:
        banner()
        print(f"{C} • Pilih menu:{W}")
        print(f"{Y}[1]{W} Jalankan tools.py")
        print(f"{Y}[2]{W} Edit Script (nano)")
        print(f"{Y}[3]{W} Jalankan cyber.py (CTF PREM)")
        print(f"{Y}[4]{W} Keluar")
        print()
        pilihan = input(f"{C} • Select > {W}")

        if pilihan == "1":
            clear()
            os.system("figlet Credit || echo 'CREDIT'")
            print(f"{G}Author : Maxtream_09{W}")
            print(f"{G}id mlbb: 551143556{W}")
            print(f"{G}irssi  : max-room{W}")
            time.sleep(2)
            if os.path.exists("tools.py"):
                os.system("python3 tools.py")
            else:
                print(f"{R}File tools.py tidak ditemukan! Pastikan tools.py ada di folder yang sama.{W}")
                input("Tekan ENTER untuk kembali...")

        elif pilihan == "2":
            if shutil.which("nano"):
                os.system("nano fadil.py")
            else:
                print(f"{R}Nano tidak ditemukan. Install dulu dengan apt/pkg install nano{W}")
                input("Tekan ENTER untuk kembali...")

        elif pilihan == "3":
            if os.path.exists("cyber.py"):
                os.system("python3 cyber.py")
            else:
                print(f"{R}File cyber.py tidak ditemukan! Pastikan cyber.py ada di folder yang sama.{W}")
                input("Tekan ENTER untuk kembali...")

        elif pilihan == "4":
            print(f"{G}✓ Exit...{W}")
            break

        else:
            print(f"{R}Input salah!{W}")
            time.sleep(1)

def main():
    clear()
    print(f"{Y}Checking system files, pastikan internet lancar...{W}")
    time.sleep(1)
    # cek dependensi dasar
    cek_paket("python3")
    cek_paket("figlet")
    cek_paket("git")
    cek_paket("pv")
    print(f"{G}✓ Semua dependensi sudah siap!{W}")
    time.sleep(1)
    menu()

if __name__ == "__main__":
    main()