// method/glory.js
const [,, target, time, thread, rate, proxyFile] = process.argv;

if (!target || !time) {
  console.log('❌ Usage: node glory.js <target> <time> <thread> <rate> <proxy.txt>');
  process.exit(1);
}

console.log(`
🔥 Simulasi GLORY Attack
🎯 Target     : ${target}
⏱ Duration   : ${time} detik
🚀 Threads    : ${thread}
⚡ Rate       : ${rate}
📂 Proxy File : ${proxyFile}

📡 Status     : Attack simulation started...
`);

setTimeout(() => {
  console.log('✅ Simulasi selesai tanpa error.');
  process.exit(0);
}, 3000);
