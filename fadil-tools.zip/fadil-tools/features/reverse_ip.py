import requests
import os

def reverse_ip_lookup():
    os.system("clear")
    print("=== Reverse IP Lookup ===")
    ip = input("Masukkan IP/domain target: ")
    try:
        url = f"https://api.hackertarget.com/reverseiplookup/?q={ip}"
        r = requests.get(url)
        if "error" in r.text or r.text.strip() == "":
            print("[!] Tidak ditemukan data.")
        else:
            print(f"[✓] Domain terkait:\n\n{r.text}")
    except Exception as e:
        print(f"[!] Error: {e}")

if __name__ == "__main__":
    reverse_ip_lookup()