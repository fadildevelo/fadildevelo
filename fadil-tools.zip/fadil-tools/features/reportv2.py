import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import time
import os

# Fungsi warna
def print_colored(text, color):
    color_codes = {
        "tosca": "\033[1;36m",
        "merah": "\033[1;31m",
        "putih": "\033[1;37m",
        "reset": "\033[0m",
    }
    print(f"{color_codes.get(color, '')}{text}{color_codes['reset']}")

# Konfigurasi Gmail
sender_email = "fire.send482@gmail.com"
sender_pass = "dpusbvnihmvncaob"

receiver_emails = [
    "smb@support.whatsapp.com",
    "support@support.whatsapp.com"
]

menu_pelanggaran = {
    "1": ("Spam", "Nomor ini mengirimkan pesan spam dan link mencurigakan."),
    "2": ("Penipuan", "Nomor ini melakukan penipuan dengan modus undian, hadiah palsu."),
    "3": ("Ujaran Kebencian", "Nomor ini menyebarkan ujaran kebencian."),
    "4": ("Konten 18+", "Nomor ini menyebarkan konten dewasa."),
    "5": ("Pelecehan", "Nomor ini melakukan pelecehan."),
    "6": ("Ancaman/Kekerasan", "Nomor ini mengirimkan ancaman kekerasan.")
}

# Clear dan tampilkan menu
os.system("clear")
print_colored("=== MENU PELAPORAN WHATSAPP ===", "tosca")
for key, value in menu_pelanggaran.items():
    print(f"{key}. {value[0]}")

# Input
pilihan = input("\nPilih jenis pelanggaran (1-6): ").strip()
if pilihan not in menu_pelanggaran:
    print_colored("[!] Pilihan tidak valid.", "merah")
    exit()

judul, deskripsi = menu_pelanggaran[pilihan]
nomor_input = input("Masukkan nomor (pisahkan koma jika lebih dari satu): ")
jumlah_kirim = input("Masukkan jumlah pengiriman per nomor: ").strip()

if not jumlah_kirim.isdigit() or int(jumlah_kirim) <= 0:
    print_colored("[!] Jumlah pengiriman tidak valid.", "merah")
    exit()

jumlah_kirim = int(jumlah_kirim)
numbers = [x.strip() for x in nomor_input.split(",")]

log = open("log.txt", "w")

for nomor in numbers:
    for _ in range(jumlah_kirim):
        subject = f"Laporan WhatsApp - {judul} - {nomor}"
        body = f"""
Yth. Tim WhatsApp,

Saya ingin melaporkan nomor berikut karena dugaan pelanggaran.

Nomor: {nomor}
Jenis Pelanggaran: {judul}
Deskripsi: {deskripsi}

Terima kasih.
"""

        for email_tujuan in receiver_emails:
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = email_tujuan
            msg['Subject'] = subject
            msg.attach(MIMEText(body, 'plain'))

            try:
                smtp = smtplib.SMTP_SSL('smtp.gmail.com', 465)
                smtp.login(sender_email, sender_pass)
                smtp.send_message(msg)
                smtp.quit()
            except Exception as e:
                log.write(f"[x] {nomor} -> {email_tujuan} | GAGAL: {e}\n")

        print_colored(f"[✓] Report nomor {nomor} berhasil", "tosca")
        log.write(f"[✓] {nomor} -> BERHASIL\n")
        time.sleep(2)

log.close()
print_colored("\n[!] Semua selesai. Cek log.txt untuk detail.", "tosca")
