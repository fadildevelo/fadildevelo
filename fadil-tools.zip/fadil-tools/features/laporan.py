import os
import time

log_file = "wa_report_log.txt"

def lapor_nomor():
    os.system("clear")
    print("📌 Pelaporan Nomor WhatsApp Bermasalah\n")

    nomor = input("📱 Masukkan nomor WA (cth: 6281234567890): ").strip()
    alasan = input("📝 Alasan pelaporan: ").strip()
    waktu = time.strftime("%d-%m-%Y %H:%M:%S")

    with open(log_file, "a") as f:
        f.write(f"{waktu} | {nomor} | {alasan}\n")

    print(f"\n✅ Nomor {nomor} berhasil ditandai sebagai bermasalah.")
    input("Tekan Enter untuk kembali...")

def lihat_log():
    os.system("clear")
    print("📂 Daftar Nomor yang Ditandai:\n")

    if not os.path.exists(log_file):
        print("⚠️ Belum ada laporan.")
    else:
        with open(log_file, "r") as f:
            print(f.read())

    input("Tekan Enter untuk kembali...")

def menu():
    while True:
        os.system("clear")
        print("""
============================
🔒 WA REPORT LOGGER
============================
[1] 🚨 Laporkan Nomor WA
[2] 📄 Lihat Log Laporan
[0] ❌ Keluar
""")
        pilih = input("Pilih opsi > ")

        if pilih == "1":
            lapor_nomor()
        elif pilih == "2":
            lihat_log()
        elif pilih == "0":
            break
        else:
            print("❌ Pilihan tidak valid.")
            time.sleep(1)

if __name__ == "__main__":
    menu()