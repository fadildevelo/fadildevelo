import requests
import re
import json
import os

def clear():
    os.system('clear' if os.name == 'posix' else 'cls')

def get_ig_info(username):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; Mobile)',
    }

    url = f"https://www.instagram.com/{username}/"

    try:
        r = requests.get(url, headers=headers)
        html = r.text

        data = re.search(r'window\._sharedData = (.*?);</script>', html)
        if not data:
            print("❌ Gagal mengambil data, mungkin akun private atau tidak ditemukan.")
            return

        json_data = json.loads(data.group(1))
        user = json_data['entry_data']['ProfilePage'][0]['graphql']['user']

        print(f"\n🔍 Informasi Instagram untuk @{username}")
        print(f"👤 Nama: {user['full_name']}")
        print(f"📝 Bio: {user['biography']}")
        print(f"🌍 Link: https://instagram.com/{username}")
        print(f"📷 Postingan: {user['edge_owner_to_timeline_media']['count']}")
        print(f"👥 Followers: {user['edge_followed_by']['count']}")
        print(f"👤 Following: {user['edge_follow']['count']}")
        print(f"🔒 Private: {'Ya' if user['is_private'] else 'Tidak'}")
        print(f"✅ Verified: {'Ya' if user['is_verified'] else 'Tidak'}")

    except Exception as e:
        print(f"❌ Gagal mengambil data: {e}")

if __name__ == '__main__':
    clear()
    print("=== IG TRACKER [HTML SCRAPER] ===")
    user = input("Masukkan username Instagram: ").strip()
    get_ig_info(user)