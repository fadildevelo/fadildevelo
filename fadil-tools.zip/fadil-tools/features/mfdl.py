import requests
from bs4 import BeautifulSoup
import re
import os

def mediafire_download(url):
    if "mediafire.com" not in url:
        print("[!] Masukkan link mediafire yang valid.")
        return

    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 11) Gecko/20100101 Firefox/89.0"
    }

    try:
        print("[*] Mengambil data dari halaman Mediafire...")
        res = requests.get(url, headers=headers)
        soup = BeautifulSoup(res.text, "html.parser")

        filename = soup.select_one('.filename').text.strip()
        filesize = soup.select_one('.fileInfo span:nth-child(2)').text.strip()
        download_url = soup.select_one('a#downloadButton')['href']

        print("\n╭─────[ ᴅᴏᴡɴʟᴏᴀᴅ - ᴍᴇᴅɪᴀғɪʀᴇ ]─────")
        print(f"│ 📄 Nama File   : {filename}")
        print(f"│ 💾 Ukuran File : {filesize}")
        print(f"│ 🔗 URL         : {download_url}")
        print("╰────────────────────────────────────")

        confirm = input(f"\n[?] Ingin download file ini? (y/n): ").lower()
        if confirm == 'y':
            download_file(download_url, filename)
        else:
            print("[!] Download dibatalkan.")

    except Exception as e:
        print("[!] Gagal parsing manual. Coba pakai API fallback...")
        fallback_api(url)

def download_file(url, filename):
    print(f"[*] Mengunduh file {filename}...")
    r = requests.get(url, stream=True)
    total = int(r.headers.get('content-length', 0))
    with open(filename, 'wb') as f:
        downloaded = 0
        for data in r.iter_content(chunk_size=1024):
            downloaded += len(data)
            f.write(data)
            done = int(50 * downloaded / total)
            print(f"\r[{'█' * done}{'.' * (50-done)}] {downloaded//1024}/{total//1024} KB", end='')
    print(f"\n[✓] File berhasil diunduh: {filename}")

def fallback_api(url):
    try:
        api = f"https://api.botwa.space/api/mediafire?url={url}&apikey=90x5sFRa1Xlc"
        res = requests.get(api).json()
        if res.get("status") == 200:
            result = res["result"]
            print("\n╭─────[ ᴅᴏᴡɴʟᴏᴀᴅ - ᴀᴘɪ ғᴀʟʟʙᴀᴄᴋ ]─────")
            print(f"│ 📄 Nama File   : {result['filename']}")
            print(f"│ 💾 Ukuran File : {result['filesize']}")
            print(f"│ 🕒 Upload Date : {result['uploadAt']}")
            print(f"│ 🔗 URL         : {result['link']}")
            print("╰──────────────────────────────────────────")
            
            confirm = input(f"\n[?] Ingin download file ini? (y/n): ").lower()
            if confirm == 'y':
                download_file(result['link'], result['filename'])
            else:
                print("[!] Download dibatalkan.")
        else:
            print("[✘] Gagal mengambil data dari API.")
    except Exception as e:
        print(f"[✘] Error: {e}")

if __name__ == "__main__":
    print("===[ Mediafire Downloader Tool ]===")
    mediafire_url = input("Masukkan link Mediafire: ")
    mediafire_download(mediafire_url)