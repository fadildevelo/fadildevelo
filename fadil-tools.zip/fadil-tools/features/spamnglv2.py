import requests
import time
import uuid
import random
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
os.system('clear')
banner = """
╔═╗╦═╗╦  ╔═╗╦═╗╔═╗╔╦╗  ╔═╗╔═╗╦═╗
║  ╠╦╝║  ║╣ ╠╦╝╠═╣║║║  ╠═╣╠═╣╠╦╝
╚═╝╩╚═╩═╝╚═╝╩╚═╩ ╩╩ ╩  ╩ ╩╩ ╩╩╚═
       [ + ] InfernalXploit NGL Spammer
"""

print(banner)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Bot InfernalXploit NGL Spammer siap digunakan!\n\n"
        "Gunakan perintah:\n"
        "/send_ngl <link_ngl> <jumlah> <pesan>\n\n"
        "Contoh:\n"
        "/send_ngl https://ngl.link/sennaaak_ 5 Halo ini spam!"
    )

async def send_ngl(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args

    if len(args) < 3:
        await update.message.reply_text("Format salah!\nGunakan:\n/send_ngl <link_ngl> <jumlah> <pesan>")
        return

    ngl_link = args[0]
    try:
        jumlah = int(args[1])
    except ValueError:
        await update.message.reply_text("Jumlah harus berupa angka!")
        return

    pesan = " ".join(args[2:])
    username = ngl_link.split("/")[-1]

    url = "https://ngl.link/api/submit"
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "Mozilla/5.0 (Linux; Android 11; SM-A107F)",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0"
    ]

    await update.message.reply_text(f"Mulai mengirim {jumlah} pesan ke {ngl_link}...\n")

    for i in range(jumlah):
        data = {
            "username": username,
            "question": f"{pesan} #{i+1}",
            "deviceId": str(uuid.uuid4())
        }
        headers = {
            "User-Agent": random.choice(user_agents),
            "Content-Type": "application/x-www-form-urlencoded"
        }
        try:
            response = requests.post(url, data=data, headers=headers)
            if response.status_code == 200 and response.json().get("success", False):
                await update.message.reply_text(f"Pesan {i+1} BERHASIL dikirim!")
            else:
                await update.message.reply_text(f"Pesan {i+1} BERHASIL (Status: {response.status_code})")
        except Exception as e:
            await update.message.reply_text(f"Pesan {i+1} ERROR: {e}")
        time.sleep(2)

    await update.message.reply_text("✅ Selesai mengirim semua pesan!")

def main():
    token = input("Masukkan token bot Telegram kamu: ").strip()
    app = ApplicationBuilder().token(token).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("send_ngl", send_ngl))

    print("Bot berjalan...")
    app.run_polling()

if __name__ == "__main__":
    main()
