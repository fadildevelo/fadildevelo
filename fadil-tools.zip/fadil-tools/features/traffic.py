import requests
import socket
import time
from urllib.parse import urlparse

R = '\033[91m'
G = '\033[92m'
Y = '\033[93m'
C = '\033[96m'
W = '\033[0m'

def cek_traffic():
    try:
        domain = input(f"{Y}Masukkan domain (cth: tokopedia.com): {W}").strip()

        if not domain:
            print(f"{R}Domain tidak boleh kosong!{W}")
            return

        print(f"{C}🔍 Mengecek trafik untuk: {domain} ...{W}")
        time.sleep(1)

        # Coba resolve DNS
        try:
            ip = socket.gethostbyname(domain)
            print(f"{G}✔ IP ditemukan: {ip}{W}")
        except socket.gaierror:
            print(f"{R}❌ Gagal resolve domain, pastikan domain benar.{W}")
            return

        # Akses via layanan informasi trafik eksternal
        headers = {
            'User-Agent': 'Mozilla/5.0 (compatible; traffic-checker/1.0)'
        }

        # Gunakan data dari statshow.com (alternatif open source)
        url = f"https://www.statshow.com/www/{domain}"
        res = requests.get(url, headers=headers, timeout=10)

        if res.status_code != 200:
            print(f"{R}❌ Gagal mengakses statshow.com, status: {res.status_code}{W}")
            return

        # Ambil estimasi trafik secara kasar
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(res.text, 'html.parser')
        traffic_info = soup.find_all("div", class_="top-info-data")

        if traffic_info:
            for item in traffic_info:
                label = item.find("div", class_="top-info-title")
                value = item.find("div", class_="top-info-value")
                if label and value:
                    print(f"{Y}{label.text.strip()}: {W}{value.text.strip()}")
        else:
            print(f"{R}❌ Tidak bisa menemukan informasi trafik domain.{W}")

    except Exception as e:
        print(f"{R}❌ Gagal mengambil data: {e}{W}")

    input(f"\n{C}Tekan Enter untuk keluar...{W}")