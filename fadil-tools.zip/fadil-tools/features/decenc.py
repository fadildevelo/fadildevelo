# Bagian atas: import dan fungsi warna
import os
import base64, urllib.parse, codecs

R = '\033[91m'
G = '\033[92m'
Y = '\033[93m'
B = '\033[94m'
C = '\033[96m'
W = '\033[0m'

# ==================== DECODE FUNCTIONS ====================
def decode_base64(data):
    try: return base64.b64decode(data.encode()).decode()
    except Exception as e: return f"Error: {e}"

def decode_hex(data):
    try: return bytes.fromhex(data).decode()
    except Exception as e: return f"Error: {e}"

def decode_url(data):
    try: return urllib.parse.unquote(data)
    except Exception as e: return f"Error: {e}"

def decode_rot13(data):
    try: return codecs.decode(data, 'rot_13')
    except Exception as e: return f"Error: {e}"

def decode_binary(data):
    try: return ''.join([chr(int(b, 2)) for b in data.split()])
    except Exception as e: return f"Error: {e}"

def menu_decode():
    while True:
        print("\n=== DECODE TOOLS ===")
        print("1. Base64 Decode")
        print("2. Hex Decode")
        print("3. URL Decode")
        print("4. ROT13 Decode")
        print("5. Binary Decode")
        print("0. Kembali ke menu utama")
        choice = input("Pilih jenis decode: ")

        if choice == '0':
            break

        teks = input("Masukkan teks yang akan didecode: ")

        match choice:
            case '1': print("Hasil:", decode_base64(teks))
            case '2': print("Hasil:", decode_hex(teks))
            case '3': print("Hasil:", decode_url(teks))
            case '4': print("Hasil:", decode_rot13(teks))
            case '5': print("Hasil:", decode_binary(teks))
            case _: print("Pilihan tidak valid.")

        input("\nTekan Enter untuk melanjutkan...")

# ==================== MENU UTAMA ====================
def menu():
    while True:
        print(f"""{C}
╭─── MENU TOOLS ───╮
│ [01] Spam Bot Telegram
│ [02] Spam Email
│ [33] Decode Tools
│ [00] Keluar
╰──────────────────╯{W}""")
        p = input(f"{C}Pilih Menu > {W}")
        try:
            match p:
                case "1": spam_bot_telegram()
                case "2": spam_email()
                case "33": menu_decode()  # ✅ ini panggil decode
                case "0":
                    print(f"{Y}Keluar dari tools...{W}")
                    break
                case _:
                    print(f"{R}Pilihan tidak tersedia!{W}")
        except Exception as e:
            print(f"{R}[!] Error: {e}{W}")
        input(f"\n{B}Tekan Enter untuk kembali...{W}")

if __name__ == "__main__":
    menu()