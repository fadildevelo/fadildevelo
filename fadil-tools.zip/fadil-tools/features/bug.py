import os

def print_header():
    print("\n" + "="*50)
    print("         BUG HUNTER INTERAKTIF PANEL")
    print("="*50 + "\n")

def get_input(prompt):
    return input(f"[+] {prompt}: ")

def main():
    print_header()
    target = get_input("Target domain (cth: example.com)")
    platform = get_input("Platform (cth: HackerOne/Bugcrowd)")
    method = get_input("Metode/bug (cth: XSS/SQLi/RCE)")
    tools = get_input("Tools yang digunakan (cth: gau, httpx, dalfox)")
    payload = get_input("Payload yang digunakan")
    bukti = get_input("Link/penjelasan bukti (cth: POC video/img)")
    impact = get_input("Dampak bug (cth: account takeover, bypass auth)")

    print("\n[✓] Ringkasan Temuan Bug:")
    print(f"    ▸ Target     : {target}")
    print(f"    ▸ Platform   : {platform}")
    print(f"    ▸ Metode     : {method}")
    print(f"    ▸ Tools      : {tools}")
    print(f"    ▸ Payload    : {payload}")
    print(f"    ▸ Bukti/POC  : {bukti}")
    print(f"    ▸ Dampak     : {impact}")

    simpan = input("\n[?] Simpan laporan ke file txt? (y/n): ").lower()
    if simpan == 'y':
        os.makedirs("bug_report", exist_ok=True)
        filename = f"bug_report/hasil_{target.replace('.', '_')}.txt"
        with open(filename, "w") as f:
            f.write("==== Laporan Bug Hunter ====\n")
            f.write(f"Target     : {target}\n")
            f.write(f"Platform   : {platform}\n")
            f.write(f"Metode     : {method}\n")
            f.write(f"Tools      : {tools}\n")
            f.write(f"Payload    : {payload}\n")
            f.write(f"Bukti/POC  : {bukti}\n")
            f.write(f"Dampak     : {impact}\n")
        print(f"\n[✓] Laporan berhasil disimpan di: {filename}")

if __name__ == "__main__":
    main()