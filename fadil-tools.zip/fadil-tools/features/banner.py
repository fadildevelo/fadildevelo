import pyfiglet
import os
os.system('clear')
text = input("MASUKIN TEXT LOE: ").upper()
ascii_art = pyfiglet.figlet_format(text, font="ansi_shadow")  # Font mirip "EndernalK"
print(ascii_art)

# Simpan ke file
with open("banner.txt", "w") as f:
    f.write(ascii_art)
print("Saved as 'banner.txt'!")
