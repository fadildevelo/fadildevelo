
# Versi pendek: hanya bagian awal contoh
#!/usr/bin/env python3

VERSION = '1.3.1'

R = '\033[31m'  # red
G = '\033[32m'  # green
C = '\033[36m'  # cyan
W = '\033[0m'  # white
Y = '\033[33m'  # yellow

import sys
import utils
import argparse
import requests
import traceback
import shutil
from time import sleep
from os import path, kill, mkdir, getenv, environ, remove, devnull
from json import loads, decoder
from packaging import version

parser = argparse.ArgumentParser()
parser.add_argument('-k', '--kml', help='KML filename')
parser.add_argument(
    '-p', '--port', type=int, default=8080, help='Web server port [ Default : 8080 ]'
)
parser.add_argument('-u', '--update', action='store_true', help='Check for updates')
parser.add_argument('-v', '--version', action='store_true', help='Prints version')

# Contoh perbaikan
def chk_update():
    try:
        print('> Fetching Metadata...', end='')
        rqst = requests.get('https://raw.githubusercontent.com/thewhiteh4t/seeker/master/metadata.json', timeout=5)
        if rqst.status_code == 200:
            print('OK')
            data = rqst.json()
            print(f"Latest version: {data['version']}")
    except Exception as e:
        print(f'Error: {e}')