import os, requests, socket, re
from datetime import datetime

def ip_public():
    try:
        ip = requests.get("https://api.ipify.org").text
        print(f"[✓] IP Publik Anda: {ip}")
    except:
        print("[!] Gagal mengambil IP.")

def port_scan():
    host = input("Target (IP/domain): ")
    ports = [21, 22, 23, 25, 53, 80, 110, 139, 443, 445, 8080]
    print(f"[~] Scanning {host}...")
    for port in ports:
        try:
            sock = socket.socket()
            sock.settimeout(0.5)
            result = sock.connect_ex((host, port))
            if result == 0:
                print(f"[OPEN] Port {port}")
            sock.close()
        except:
            pass

def subdomain_finder():
    domain = input("Domain target: ")
    sublist = ["www", "mail", "ftp", "cpanel", "webmail"]
    for sub in sublist:
        url = f"http://{sub}.{domain}"
        try:
            r = requests.get(url, timeout=2)
            print(f"[✓] Subdomain ditemukan: {url}")
        except:
            pass

def admin_finder():
    target = input("URL target: ")
    paths = ["admin", "login", "admin/login", "wp-admin", "panel"]
    for path in paths:
        url = f"{target}/{path}"
        try:
            r = requests.get(url, timeout=2)
            if r.status_code == 200:
                print(f"[✓] Admin page ditemukan: {url}")
        except:
            pass

def wp_scan():
    target = input("URL WordPress: ")
    try:
        r = requests.get(f"{target}/readme.html", timeout=2)
        if "wordpress" in r.text.lower():
            print("[+] Target menggunakan WordPress!")
        else:
            print("[-] Tidak terdeteksi WordPress.")
    except:
        print("[!] Gagal koneksi.")

def whois_lookup():
    domain = input("Domain: ")
    try:
        data = requests.get(f"https://api.hackertarget.com/whois/?q={domain}").text
        print(data)
    except:
        print("[!] Gagal cek WHOIS.")

def geoip():
    ip = input("IP target: ")
    try:
        data = requests.get(f"http://ip-api.com/json/{ip}").json()
        for k, v in data.items():
            print(f"{k} : {v}")
    except:
        print("[!] Gagal mendapatkan lokasi.")

def fake_login_page():
    html = """<html><body><h2>Login</h2><form><input placeholder='Username'><br><input type='password' placeholder='Password'><br><button>Login</button></form></body></html>"""
    with open("fake_login.html", "w") as f:
        f.write(html)
    print("[✓] fake_login.html dibuat.")

def dork_scan():
    dork = input("Masukkan dork (contoh: inurl:admin): ")
    print("[!] Gunakan langsung di Google untuk hasil terbaik.")
    print(f"https://www.google.com/search?q={dork}")

def sql_test():
    url = input("Target URL (contoh: http://site.com/page.php?id=1): ")
    payloads = ["'", "'--", "' or '1'='1", "' OR 1=1--"]
    print("[~] Testing payload...")
    for p in payloads:
        test_url = url + p
        try:
            r = requests.get(test_url, timeout=3)
            if "mysql" in r.text.lower() or "error" in r.text.lower():
                print(f"[!] Potensi SQLi ditemukan: {test_url}")
        except:
            pass

def menu():
    os.system("clear")
    print("=== Hacker Tools Edukasi ===")
    print("1. Cek IP Publik")
    print("2. Port Scanner")
    print("3. Subdomain Finder")
    print("4. Admin Page Finder")
    print("5. WP Scan")
    print("6. WHOIS Lookup")
    print("7. Geo IP Tracker")
    print("8. Generate Fake Login Page")
    print("9. Dork Scanner")
    print("10. SQL Injection Tester")
    print("0. Keluar")

    pilih = input("Pilih: ")
    if pilih == "1": ip_public()
    elif pilih == "2": port_scan()
    elif pilih == "3": subdomain_finder()
    elif pilih == "4": admin_finder()
    elif pilih == "5": wp_scan()
    elif pilih == "6": whois_lookup()
    elif pilih == "7": geoip()
    elif pilih == "8": fake_login_page()
    elif pilih == "9": dork_scan()
    elif pilih == "10": sql_test()
    elif pilih == "0": exit()
    else: print("Pilihan salah.")
    input("\nTekan Enter untuk kembali...")
    menu()

if __name__ == "__main__":
    menu()