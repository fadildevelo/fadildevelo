import os
import openai
import pyfiglet
from termcolor import colored

def load_api_key():
    file_path = os.path.join(os.getcwd(), 'api.txt')
    if not os.path.exists(file_path) or os.stat(file_path).st_size == 0:
        with open(file_path, 'w') as f:
            key = input("Masukkan OpenAI API key kamu: ").strip()
            f.write(key)
        print(colored("[✓] API key disimpan ke api.txt", "green"))

    with open(file_path, 'r') as f:
        return f.read().strip()

def main():
    api_key = load_api_key()
    openai.api_key = api_key

    os.system("clear")
    banner = pyfiglet.figlet_format("ChatGPT")
    print(colored(banner, 'green'))

    while True:
        try:
            prompt = input(colored("Tulis pertanyaanmu (atau ketik 'exit'): ", 'cyan')).strip()
            if prompt.lower() == 'exit':
                print(colored("Keluar dari ChatGPT CLI...", "yellow"))
                break

            print(colored(">> Menjawab...\n", 'blue'))

            response = openai.Completion.create(
                engine='text-davinci-003',
                prompt=prompt,
                max_tokens=500,
                temperature=0.7
            )
            print(colored("💬 Jawaban:\n", "green"))
            print(response.choices[0].text.strip())
            print()
        except Exception as e:
            print(colored(f"[!] Terjadi error: {e}", "red"))
            break

if __name__ == "__main__":
    main()