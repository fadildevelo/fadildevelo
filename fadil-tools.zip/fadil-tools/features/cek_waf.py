import os

def cek_waf():
    target = input("Masukkan URL target (contoh: https://example.com): ")
    print("[*] Mengecek WAF...")
    os.system(f"wafw00f {target}")

if __name__ == "__main__":
    cek_waf()