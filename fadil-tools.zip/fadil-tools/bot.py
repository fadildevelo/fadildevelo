from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters
import logging
import aiohttp
import asyncio

# --- Logging ---
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# --- Token Bot Telegrammu ---
TOKEN = "7876545031:AAG03DrgXmKVEXDuOCxRO8w1lXo1mbjHtoI"

# Endpoint AI gratis
AI_URL = "https://api.akuari.my.id"

# --- Fungsi command /start ---
async def start(update, context):
    await update.message.reply_text("✅ Bot AI aktif! Tanyakan apapun ke aku 😊")

# --- Fungsi AI ---
async def ask_ai(prompt: str) -> str:
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(f"{AI_URL}?message={prompt}") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    # data = { 'message': 'jawaban dari AI' }
                    return data.get("message", "🤖 [AI tidak membalas]")
                else:
                    return f"❌ [AI error {resp.status}]"
    except Exception as e:
        return f"❌ [Gagal menghubungi AI: {e}]"

# --- Fungsi balas teks ---
async def echo(update, context):
    user_text = update.message.text
    await update.message.reply_text("⏳ Tunggu sebentar, AI sedang berpikir...")
    jawaban = await ask_ai(user_text)
    await update.message.reply_text(jawaban)

# --- Main ---
if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
    print("🚀 Bot AI sedang berjalan...")
    app.run_polling()