#!/usr/bin/env python3
import base64, hashlib, binascii, requests, socket, exifread, os, string

W = "\033[0m"; G = "\033[32m"; R = "\033[31m"; C = "\033[36m"; Y = "\033[33m"

def banner():
    os.system("clear")
    print(f"""{C}
╔══════════════════════════════════════════════╗
║     🚩 CTF HELPER TOOLS by FadilDev 🚩       ║
╠══════════════════════════════════════════════╣
║ [1] Base64 Encode/Decode                      ║
║ [2] URL Encode/Decode                         ║
║ [3] Hex Encode/Decode                         ║
║ [4] Hash Generator (MD5/SHA1/SHA256)          ║
║ [5] Extract Strings from File                 ║
║ [6] Caesar Cipher Decoder (Brute)             ║
║ [7] XOR Brute-force (1 byte key)              ║
║ [8] Port Scanner                              ║
║ [9] File Metadata (EXIF)                      ║
║ [10] WHOIS Domain                             ║
║ [0] Keluar                                    ║
╚══════════════════════════════════════════════╝
{W}""")

def base64_tools():
    data = input(f"{Y}[?] Masukkan teks: {W}")
    print(f"{G}Base64 Encode:{W} {base64.b64encode(data.encode()).decode()}")
    try:
        print(f"{C}Base64 Decode:{W} {base64.b64decode(data).decode()}")
    except:
        print(f"{R}[!] Data bukan Base64 valid{W}")
    input("Enter untuk kembali...")

def url_tools():
    from urllib.parse import quote, unquote
    data = input(f"{Y}[?] Masukkan teks/URL: {W}")
    print(f"{G}URL Encode:{W} {quote(data)}")
    print(f"{C}URL Decode:{W} {unquote(data)}")
    input("Enter untuk kembali...")

def hex_tools():
    data = input(f"{Y}[?] Masukkan teks: {W}")
    print(f"{G}Hex Encode:{W} {binascii.hexlify(data.encode()).decode()}")
    try:
        print(f"{C}Hex Decode:{W} {binascii.unhexlify(data).decode()}")
    except:
        print(f"{R}[!] Data bukan Hex valid{W}")
    input("Enter untuk kembali...")

def hash_tools():
    data = input(f"{Y}[?] Masukkan teks: {W}")
    print(f"{G}MD5:{W} {hashlib.md5(data.encode()).hexdigest()}")
    print(f"{C}SHA1:{W} {hashlib.sha1(data.encode()).hexdigest()}")
    print(f"{Y}SHA256:{W} {hashlib.sha256(data.encode()).hexdigest()}")
    input("Enter untuk kembali...")

def extract_strings():
    path = input(f"{Y}[?] Masukkan path file: {W}")
    try:
        with open(path,"rb") as f:
            data = f.read()
            hasil = ''.join([c if chr(c) in string.printable else ' ' for c in data])
            print(f"{G}[✓] String ditemukan:{W}\n{hasil}")
    except Exception as e:
        print(f"{R}[!] Gagal: {e}{W}")
    input("Enter untuk kembali...")

def caesar_brute():
    teks = input(f"{Y}[?] Masukkan teks terenkripsi: {W}")
    for k in range(26):
        hasil = ""
        for char in teks:
            if char.isalpha():
                base = 'A' if char.isupper() else 'a'
                hasil += chr((ord(char) - ord(base) - k) % 26 + ord(base))
            else:
                hasil += char
        print(f"{C}Shift {k}:{W} {hasil}")
    input("Enter untuk kembali...")

def xor_brute():
    data = input(f"{Y}[?] Masukkan teks terenkripsi (hex): {W}")
    try:
        raw = bytes.fromhex(data)
        for k in range(256):
            out = ''.join(chr(b ^ k) if 32 <= (b ^ k) <= 126 else '.' for b in raw)
            print(f"{C}Key {k}:{W} {out}")
    except Exception as e:
        print(f"{R}[!] Error: {e}{W}")
    input("Enter untuk kembali...")

def port_scan():
    host = input(f"{Y}[?] Masukkan host: {W}")
    ports = [21,22,23,25,53,80,110,143,443,3306,8080]
    for p in ports:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5)
            res = s.connect_ex((host, p))
            if res == 0:
                print(f"{G}[OPEN]{W} Port {p}")
            s.close()
        except:
            pass
    input("Enter untuk kembali...")

def exif_meta():
    path = input(f"{Y}[?] Masukkan path gambar: {W}")
    try:
        with open(path, 'rb') as f:
            tags = exifread.process_file(f)
            for tag in tags:
                print(f"{C}{tag}:{W} {tags[tag]}")
    except Exception as e:
        print(f"{R}[!] Gagal: {e}{W}")
    input("Enter untuk kembali...")

def whois_check():
    domain = input(f"{Y}[?] Masukkan domain: {W}")
    try:
        r = requests.get(f"https://api.hackertarget.com/whois/?q={domain}", timeout=5)
        print(r.text)
    except Exception as e:
        print(f"{R}[!] Gagal: {e}{W}")
    input("Enter untuk kembali...")

def main():
    while True:
        banner()
        pil = input(f"{Y}[?] Pilih menu: {W}")
        if pil == "1": base64_tools()
        elif pil == "2": url_tools()
        elif pil == "3": hex_tools()
        elif pil == "4": hash_tools()
        elif pil == "5": extract_strings()
        elif pil == "6": caesar_brute()
        elif pil == "7": xor_brute()
        elif pil == "8": port_scan()
        elif pil == "9": exif_meta()
        elif pil == "10": whois_check()
        elif pil == "0": print(f"{G}✓ Keluar...{W}"); break
        else:
            print(f"{R}[!] Pilihan tidak valid{W}")
            time.sleep(1)

if __name__ == "__main__":
    main()